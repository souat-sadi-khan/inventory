<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\Account;
use App\Models\Admin\AccountTransaction;
use App\Models\Customer;
use App\Models\Products\Product;
use App\Models\Supplier;
use App\Models\Vehicle\VehicleTransaction;
use App\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class ReportController extends Controller
{
    //

    public function index()
    {
        return view('admin.report.index');
    }

    public function trial_balance()
    {
        return view('admin.report.trial-balance');
    }


    public function trial_balance_show(Request $request)
    {

        $date = $request->operation_date;
        $accounts = Account::groupBy('category')->get();
        $data = [];
        foreach ($accounts as $account) {
            $category = $account->category;
            $data[$category] = [
                'Debit' => $this->account_calculation($category, 'Debit', $date),
                'Credit' => $this->account_calculation($category, 'Credit', $date),
            ];
        }

        $data['Purchase'] = [
            'Credit' => $this->sell_calculation('Purchase', $date),
            'Debit' => $this->sell_calculation('purchase_return', $date),
        ];

        $data['Sale'] = [
            'Credit' => $this->sell_calculation('sale_return', $date),
            'Debit' => $this->sell_calculation('Sale', $date),
        ];


        $data['Opening_Balance'] = [
            'Debit' => $this->opening_balance_calculation('Credit', $date),
            'Credit' => $this->opening_balance_calculation('Debit', $date),
        ];

        $data['Vehicle_Transaction'] = [
            'Debit' => $this->vehicle_calculation('Income', $date),
            'Credit' => $this->vehicle_calculation('Expence', $date),
        ];

        return view('admin.report.trial-balance-table', compact('data'));

    }


    protected function sell_calculation($sub_type, $start_date = Null, $end_date = Null)
    {
        $q = AccountTransaction::where('sub_type', $sub_type);
        if ($start_date and $end_date) {
            $q = $q->where('sub_type', $sub_type)->where('operation_date', '>=', $start_date)->where('operation_date', '<=', $end_date);
        } elseif ($start_date) {
            $q = $q->where('sub_type', $sub_type)->where('operation_date', $start_date);
        }
        return $q->sum('amount');
    }

    protected function vehicle_calculation($sub_type, $start_date = Null, $end_date = Null)
    {
        $q = VehicleTransaction::where('type', $sub_type);
        if ($start_date and $end_date) {
            $q = $q->where('type', $sub_type)->where('date', '>=', $start_date)->where('date', '<=', $end_date);
        } elseif ($start_date) {
            $q = $q->where('type', $sub_type)->where('date', $start_date);
        }
        return $q->sum('amount');
    }


    protected function account_calculation($account, $type, $start_date = Null, $end_date = Null)
    {

        $account = Account::where('category', $account)->get()->pluck('id');
        $trans = AccountTransaction::whereIn('account_id', $account)->where('type', $type);
        if ($start_date and $end_date) {
            $trans = $trans->where('operation_date', '>=', $start_date)->where('operation_date', '<=', $end_date);
        } elseif ($start_date) {
            $trans = $trans->where('operation_date', $start_date);
        } else {
            $trans = $trans;
        }

        return $trans->sum('amount');
    }


    public function day_book(Request $request)
    {
        $accounts = Account::where('status', 'Active')->get();
        return view('admin.report.day-book', compact('accounts'));
    }


    public function day_book_show(Request $request)
    {
        $start_date = $request->start_date;
        $end_date = $request->end_date;
        $account = $request->account;


        if ($account == 'Account') {


            $accounts = Account::groupBy('category')->get();
            $data = [];
            foreach ($accounts as $account) {
                $category = $account->category;
                $data[$category] = [
                    'Debit' => $this->account_calculation($category, 'Debit', $start_date, $end_date),
                    'Credit' => $this->account_calculation($category, 'Credit', $start_date, $end_date),
                ];
            }

            /*$data['Purchase'] = [
                'Credit' => $this->sell_calculation('Purchase', $start_date, $end_date),
                'Debit' => $this->sell_calculation('purchase_return', $start_date, $end_date),
            ];

            $data['Sale'] = [
                'Credit' => $this->sell_calculation('sale_return', $start_date, $end_date),
                'Debit' => $this->sell_calculation('Sale', $start_date, $end_date),
            ];*/

            $data['Opening_Balance'] = [
                'Debit' => $this->opening_balance_calculation('Credit', $start_date, $end_date),
                'Credit' => $this->opening_balance_calculation('Debit', $start_date, $end_date),
            ];

            return view('admin.report.day-book-account-wise', compact('data', 'start_date', 'end_date'));

            // dd($data);
        } elseif ($account == 'Customer') {
            // find all the customer
            $customers = Customer::all();
            $data = [];
            foreach ($customers as $customer) {
                $customer_id = $customer->id;
                $data[$customer_id] = [
                    'Debit' => $this->account_calculation_customer($customer_id, 'sale_return', $start_date, $end_date),
                    'Credit' => $this->account_calculation_customer($customer_id, 'Sale', $start_date, $end_date),
                ];
            }
            // dd($data);
            return view('admin.report.day-book-customer-wise', compact('data', 'start_date', 'end_date'));

        } elseif ($account == 'Supplier') {
            $suppliers = Supplier::all();
            $data = [];
            foreach ($suppliers as $supplier) {
                $supplier_id = $supplier->id;
                $data[$supplier_id] = [
                    'Debit' => $this->account_calculation_supplier($supplier_id, 'Purchase', $start_date, $end_date),
                    'Credit' => $this->account_calculation_supplier($supplier_id, 'purchase_return', $start_date, $end_date),
                ];
            }

            // dd($data);
            return view('admin.report.day-book-supplier-wise', compact('data', 'start_date', 'end_date'));
        }


    }

    protected function account_calculation_supplier($supplier_id, $tran_type = Null, $start_date = Null, $end_date = Null)
    {
        $trans = Transaction::where('supplier_id', $supplier_id)->where('transaction_type', $tran_type)->get();
        if ($start_date and $end_date) {
            $trans = $trans->where('operation_date', '>=', $start_date)->where('operation_date', '<=', $end_date);
        } elseif ($start_date) {
            $trans = $trans->where('date', $start_date);
        } else {
            $trans = $trans;
        }
        // dd($trans);

        return $trans->sum('net_total');
    }

    // account_calculation_customer
    protected function account_calculation_customer($customer_id, $tran_type, $start_date = null, $end_date = null)
    {
        $trans = Transaction::where('customer_id', $customer_id)->where('transaction_type', $tran_type)->get();
        // dd($trans);

        if ($start_date and $end_date) {
            $trans = $trans->where('date', '>=', $start_date)->where('date', '<=', $end_date);
        } elseif ($start_date) {
            $trans = $trans->where('date', $start_date);
        } else {
            $trans = $trans;
        }
        // dd($trans);

        return $trans->sum('net_total');
    }

    protected function opening_balance_calculation($type = Null, $start_date = Null, $end_date = Null)
    {
        $q = AccountTransaction::where('sub_type', 'Opening_balance');
        if ($type) {
            $q->where('type', $type);
        }
        if ($start_date and $end_date) {
            $q = $q->where('sub_type', 'Opening_balance')->where('operation_date', '>=', $start_date)->where('operation_date', '<=', $end_date);
        } elseif ($start_date) {
            $q = $q->where('sub_type', 'Opening_balance')->where('operation_date', $start_date);
        }
        return $q->sum('amount');
    }

    // ledger_book_category
    public function ledger_book_category($category)
    {
        if ($category == 'Purchase') {
            return Redirect()->route('admin.report.purchase');
        }

        if ($category == 'Sale') {
            return Redirect()->route('admin.report.sales');
        }


        if (isset($_GET['start_date'])) {
            $start_date = $_GET['start_date'];
        } else {
            return Redirect::back()->withErrors(['message', 'Start Date is Required']);
        }

        if (isset($_GET['end_date'])) {
            $end_date = $_GET['end_date'];
        } else {
            return Redirect::back()->withErrors(['message', 'End Date is Required']);
        }

        // find all the account using the cateogyy
        $accounts = Account::with(['account' => function ($q) use ($end_date, $start_date) {
            return $q->where('operation_date', '>=', $start_date)->where('operation_date', '<=', $end_date)->get();
        }])->where('category', $category)->get();

        $data = [];
        foreach ($accounts as $account) {
            $data[$account->id] = [
                'Debit' => $this->account_calc_while_category_name($account->id, 'Debit', $start_date, $end_date),
                'Credit' => $this->account_calc_while_category_name($account->id, 'Credit', $start_date, $end_date),
            ];
        }

        return view('admin.report.ledger.category', compact('data', 'category', 'start_date', 'end_date'));
    }

    // account_calc_while_category_name
    protected function account_calc_while_category_name($category_id, $type, $start_date = Null, $end_date = Null)
    {
        $q = AccountTransaction::where('account_id', $category_id)->where('type', $type);
        if ($start_date and $end_date) {
            $q = $q->where('operation_date', '>=', $start_date)->where('operation_date', '<=', $end_date);
        } else {
            $q = $q->where('operation_date', $start_date);
        }
        return $q->sum('amount');
    }

    public function ledger_book_name($id)
    {

        // find the acount
        $account = Account::findOrFail($id);

        if (isset($_GET['start_date'])) {
            $start_date = $_GET['start_date'];
        } else {
            return Redirect::back()->withErrors(['message', 'Start Date is Required']);
        }

        if (isset($_GET['end_date'])) {
            $end_date = $_GET['end_date'];
        } else {
            return Redirect::back()->withErrors(['message', 'Start Date is Required']);
        }

        $models = AccountTransaction::where('account_id', $id)->where('operation_date', '>=', $start_date)->where('operation_date', '<=', $end_date)->get();
        return view('admin.report.ledger.name', compact('models', 'account', 'start_date', 'end_date'));
    }

    // ledger_book_supplier
    public function ledger_book_supplier($id)
    {
        if (isset($_GET['start_date'])) {
            $start_date = $_GET['start_date'];
        } else {
            return Redirect::back()->withErrors(['message', 'Start Date is Required']);
        }

        if (isset($_GET['end_date'])) {
            $end_date = $_GET['end_date'];
        } else {
            return Redirect::back()->withErrors(['message', 'Start Date is Required']);
        }

        // dd('hello');

        // find the supplier
        $supplier = Supplier::findOrFail($id);

        $models = Transaction::groupBy('date')->where('date', '>=', $start_date)->where('date', '<=', $end_date)->where('supplier_id', $id)->get();
        $data = [];
        foreach ($models as $item) {
            $date = $item->date;
            $trans = Transaction::where('date', $date)->where('supplier_id', $id)->get();
            $data[$date] = [
                'Debit' => $trans->where('transaction_type', 'Purchase')->sum('net_total'),
                'Credit' => $trans->where('transaction_type', 'purchase_return')->sum('net_total'),
            ];
        }

        return view('admin.report.ledger.supplier_date', compact('data', 'supplier', 'start_date', 'end_date'));
    }

    // ledger_book_customer
    public function ledger_book_customer($id)
    {
        if (isset($_GET['start_date'])) {
            $start_date = $_GET['start_date'];
        } else {
            return Redirect::back()->withErrors(['message', 'Start Date is Required']);
        }

        if (isset($_GET['end_date'])) {
            $end_date = $_GET['end_date'];
        } else {
            return Redirect::back()->withErrors(['message', 'Start Date is Required']);
        }

        // find the supplier
        $customer = Customer::findOrFail($id);

        $models = Transaction::groupBy('date')->where('date', '>=', $start_date)->where('date', '<=', $end_date)->where('customer_id', $id)->get();
        $data = [];
        foreach ($models as $item) {
            $date = $item->date;
            $trans = Transaction::where('date', $date)->where('customer_id', $id)->get();
            $data[$date] = [
                'Debit' => $trans->where('transaction_type', 'sale_return')->sum('net_total'),
                'Credit' => $trans->where('transaction_type', 'Sale')->sum('net_total'),
            ];
        }

        return view('admin.report.ledger.customer_data', compact('data', 'customer', 'start_date', 'end_date'));
    }

    public function cashbank_book()
    {
        $bank = Account::whereIn('category', ['Bank_Account', 'Cash_in_hand'])->where('status', 'Active')->get();
        return view('admin.report.cashbank-book', compact('bank'));
    }


    public function recept_payment(Request $request)
    {
        return view('admin.report.recept-payment');
    }


    public function recept_payment_show(Request $request)
    {
        $type = $request->type;
        $models = AccountTransaction::where('sub_type', $type)->where('operation_date', '>=', $request->start_date)->where('operation_date', '<=', $request->end_date)->get();
        return view('admin.report.recept-payment-show', compact('models', 'type'));
    }

    public function loan(Request $request)
    {
        return view('admin.report.loan');
    }


    public function loan_show(Request $request)
    {
        $type = $request->type;
        $models = AccountTransaction::where('sub_type', $type)->where('operation_date', '>=', $request->start_date)->where('operation_date', '<=', $request->end_date)->get();
        return view('admin.report.loan-show', compact('models', 'type'));
    }


    public function balance_sheet()
    {
        $asset['Cash_in_hand'] = AccountTransaction::where('account_id', 1)->sum('amount');
        $asset['My_bank_Cash'] = $this->balancesheet_calculation('Bank_Account');

        $asset['Cost_Of_Good'] = $this->cost_of_good_calculation();
        $asset['Account_Receivable'] = Transaction::where('customer_id', '!=', Null)->sum('due');

        $asset['Current_assets'] = $this->balancesheet_calculation('Current_Assets');
        $asset['Direct_Expense'] = $this->balancesheet_calculation('Direct_Expanses');
        $asset['Employee_Salary'] = $this->balancesheet_calculation('Employee');
        $asset['Fixed_Assets'] = $this->balancesheet_calculation('Fixed_Assets');
        $asset['Duties_Taxes'] = $this->balancesheet_calculation('Duties_Taxes');

        $liabilities['Current_Liabilities'] = $this->balancesheet_calculation('Current_Leabillties');
//        $liabilities['Opening_Balance'] = $this->opening_balance_calculation();

        $liabilities['Sale_Income'] = $this->sale_income();
        $liabilities['Account_Payable'] = Transaction::where('supplier_id', '!=', Null)->sum('due');
        $liabilities['Purchase_discount'] = Transaction::where('supplier_id', '!=', Null)->sum('discount_amount');

        $liabilities['Direct_Income'] = $this->balancesheet_calculation('Direct_Income');
        $liabilities['Unsecured_Loans'] = $this->balancesheet_calculation('Unsecured_Loans');
        $liabilities['Bank_Loan'] = $this->balancesheet_calculation('Unsecured_Loans');
        $liabilities['Capital_Account'] = $this->balancesheet_calculation('Capital_Account');
        $liabilities['Investment'] = $this->balancesheet_calculation('Investment');

//        dd($asset);

        return view('admin.report.balance-sheet', compact('asset', 'liabilities'));
    }
    protected function sale_income(){

    }
    protected function cost_of_good_calculation()
    {
        $cost_of_good = 0;
        $purchase = Transaction::where('transaction_type', 'Purchase');
        $purchase_amount = $purchase->sum('sub_total') - $purchase->sum('discount_amount');
        $product_oppening_stock = Product::all()->sum('opening_stock_value');
        $sale = Transaction::where('transaction_type', 'Sale');

        $sale_amount = $sale->sum('sub_total') - $sale->sum('discount');
        $cost_of_good = ($purchase_amount + $product_oppening_stock) - $sale_amount;

        return $cost_of_good;
    }



    protected function balancesheet_calculation($account)
    {
        $account = Account::where('category', $account)->get()->pluck('id');
        $trans = AccountTransaction::whereIn('account_id', $account);

        $opening_balance = 0;

        return $trans->sum('amount');
    }


    public function profit_loss(Request $request)
    {
        if ($request->ajax()) {
            $sdate = $request->sdate;
            $edate = $request->edate;
            $sell = Transaction::where('transaction_type', 'Sale');

            if (!empty($sdate) && !empty($edate)) {
                $sell->whereBetween(DB::raw('date(date)'), [$sdate, $edate]);
            }
            $sell = $sell->get();

            $purchase = Transaction::where('transaction_type', 'Purchase');

            if (!empty($sdate) && !empty($edate)) {
                $purchase->whereBetween(DB::raw('date(date)'), [$sdate, $edate]);
            }
            $purchase = $purchase->get();

            $total_selling_price = $sell->sum('net_total');
            $total_purchase_price = $purchase->sum('net_total');
            $gross_profit = $total_selling_price - $total_purchase_price;

            $accounts = Account::where('category', 'Direct_Expanses')->get()->pluck('id');
            $total_expense = AccountTransaction::whereIn('account_id', $accounts);
            if (!empty($sdate) && !empty($edate)) {
                $total_expense = $total_expense->whereBetween(DB::raw('date(operation_date)'), [$sdate, $edate]);
            }
            $total_expense = $total_expense->sum('amount');

            $net_profit = $gross_profit - $total_expense;
            return view('admin.report.get_profit_loss', compact('total_selling_price', 'total_purchase_price', 'gross_profit', 'total_expense', 'net_profit'));
        }
        return view('admin.report.profit_loss');
    }


    public function product_report(Request $request)
    {
        if ($request->ajax()) {
            $product_id = $request->get('product_id');
            if ($product_id != 'all') {
                $products = Product::find($product_id);
            } else {
                $products = Product::all();
            }

            return view('admin.report.get_product_report', compact('products', 'product_id'));
        }
        $products = Product::all();
        return view('admin.report.product_report', compact('products'));
    }


    // original_day_book_show
    public function original_day_book_show()
    {
        return view('admin.report.day-book.index');
    }

    // get_day_book_report
    public function get_day_book_report(Request $request)
    {
        $start_date = $request->sdate;
        $end_date = $request->edate;

        $data = [];
        $query = AccountTransaction::where('operation_date', '>=', $start_date)->where('operation_date', '<=', $end_date)->get();
        foreach ($query as $item) {

            if ($item->type == 'Debit') {
                $debit = $item->amount;
                $credit = 0;
            } else {
                $debit = 0;
                $credit = $item->amount < 0 ? $item->amount * (-1) : $item->amount;
            }

            $account_id = $item->account_id;

            $data[] = [
                'Account' => $item->account ? $item->account->name : 'No Account',
                'Description' => $item->note,
                'voucher' => $item->sub_type,
                'voucher_no' => $item->reff_no,
                'Debit' => $debit,
                'Credit' => $credit
            ];
        }

        $report_type = 'Day Book Report';

        return view('admin.report.day-book.data', compact('data', 'start_date', 'end_date', 'report_type'));
    }

    // customer_due
    public function customer_due() {
        // find all the customr
        $customers = Customer::all();

        return view('admin.report.customer-due.index', compact('customers'));

    }

    // customer_due_ajax
    public function customer_due_ajax(Request $request) {

        $id = $request->val;

        // find all the customr
        $customers = Customer::all();

        $data = [];
        $total = 0;
        $total_paid = 0;
        $total_due = 0;

        if($id == 'all') {

            foreach($customers as $customer) {
                $customer_id = $customer->id;

                // find the customer due amount
                $due = Transaction::where('customer_id', $customer_id)->sum('due');
                $payable = Transaction::where('customer_id', $customer_id)->sum('net_total');
                $paid = Transaction::where('customer_id', $customer_id)->sum('paid');
                $invoice = Transaction::where('customer_id', $customer_id)->count();

                $data[] = [
                    'ID' => $customer_id,
                    'Invoice' => $invoice,
                    'Payable' => $payable,
                    'Paid' => $paid,
                    'Name' => $customer->customer_name,
                    'Amount' => $due,
                ];

                $total += $payable;
                $total_paid += $paid;
                $total_due += $due;

            }

        } else {

            $customer_id = $id;
            $customer = Customer::findOrFail($customer_id);
            // find the customer due amount
            $due = Transaction::where('customer_id', $customer_id)->sum('due');
            $payable = Transaction::where('customer_id', $customer_id)->sum('net_total');
            $paid = Transaction::where('customer_id', $customer_id)->sum('paid');
            $invoice = Transaction::where('customer_id', $customer_id)->count();

            $data[] = [
                'ID' => $customer_id,
                'Invoice' => $invoice,
                'Payable' => $payable,
                'Paid' => $paid,
                'Name' => $customer->customer_name,
                'Amount' => $due,
            ];

            $total += $payable;
            $total_paid += $paid;
            $total_due += $due;

        }


        return view('admin.report.customer-due.show', compact('data', 'customers', 'total', 'total_paid', 'total_due'));

    }

    // supplier_due
    public function supplier_due() {
        // find all the customr
        $suppliers = Supplier::all();

        return view('admin.report.supplier-due.index', compact('suppliers'));

    }

    // supplier_due_ajax
    public function supplier_due_ajax(Request $request) {

        $id = $request->val;

        // find all the customr
        $suppliers = supplier::all();

        $data = [];
        $total = 0;
        $total_paid = 0;
        $total_due = 0;

        if($id == 'all') {

            foreach($suppliers as $supplier) {
                $supplier_id = $supplier->id;

                // find the customer due amount
                $due = Transaction::where('supplier_id', $supplier_id)->sum('due');
                $payable = Transaction::where('supplier_id', $supplier_id)->sum('net_total');
                $paid = Transaction::where('supplier_id', $supplier_id)->sum('paid');
                $invoice = Transaction::where('supplier_id', $supplier_id)->count();

                $data[] = [
                    'ID' => $supplier_id,
                    'Invoice' => $invoice,
                    'Payable' => $payable,
                    'Paid' => $paid,
                    'Name' => $supplier->sup_name,
                    'Amount' => $due,
                ];

                $total += $payable;
                $total_paid += $paid;
                $total_due += $due;

            }

        } else {

            $supplier_id = $id;
            $supplier = Supplier::findOrFail($supplier_id);
            // find the customer due amount
            $due = Transaction::where('supplier_id', $supplier_id)->sum('due');
            $payable = Transaction::where('supplier_id', $supplier_id)->sum('net_total');
            $paid = Transaction::where('supplier_id', $supplier_id)->sum('paid');
            $invoice = Transaction::where('supplier_id', $supplier_id)->count();

            $data[] = [
                'ID' => $supplier_id,
                'Invoice' => $invoice,
                'Payable' => $payable,
                'Paid' => $paid,
                'Name' => $supplier->sup_name,
                'Amount' => $due,
            ];

            $total += $payable;
            $total_paid += $paid;
            $total_due += $due;

        }


        return view('admin.report.supplier-due.show', compact('data', 'suppliers', 'total', 'total_paid', 'total_due'));

    }

    // direct_income
    public function direct_income() {

        return view('admin.report.income.index');

    }

    // direct_income_show
    public function direct_income_show(Request $request) {
        $sdate = $request->sdate;
        $edate = $request->edate;

        // find the Direct Income  Accont
        $accounts = Account::where('category', 'Direct_Income')->get();
        $data = [];

        foreach($accounts as $account) {

            $debit = AccountTransaction::where('account_id', $account->id)->where('type', 'Debit')->where('operation_date', '>=', $sdate)->where('operation_date', '<=', $edate)->sum('amount');
            $credit = AccountTransaction::where('account_id', $account->id)->where('type', 'Credit')->where('operation_date', '>=', $sdate)->where('operation_date', '<=', $edate)->sum('amount');

            $data[] = [
                'account_name' => $account->name,
                'account_id' => $account->id,
                'Debit' => $debit,
                'Credit' => $credit,
            ];
        }

        return view('admin.report.income.show', compact('sdate', 'edate', 'data'));
    }

    // direct_expense
    public function direct_expense() {

        return view('admin.report.expense.index');
    }

    // direct_expense_show
    public function direct_expense_show(Request $request) {
        $sdate = $request->sdate;
        $edate = $request->edate;

        // find the Direct Income  Accont
        $accounts = Account::where('category', 'Direct_Expanses')->get();
        $data = [];

        foreach($accounts as $account) {

            $debit = AccountTransaction::where('account_id', $account->id)->where('type', 'Debit')->where('operation_date', '>=', $sdate)->where('operation_date', '<=', $edate)->sum('amount');
            $credit = AccountTransaction::where('account_id', $account->id)->where('type', 'Credit')->where('operation_date', '>=', $sdate)->where('operation_date', '<=', $edate)->sum('amount');

            $data[] = [
                'account_name' => $account->name,
                'account_id' => $account->id,
                'Debit' => $debit,
                'Credit' => $credit,
            ];
        }

        return view('admin.report.expense.show', compact('sdate', 'edate', 'data'));
    }

}

