<?php

namespace App\Http\Controllers\Admin\Account;

use App\Http\Controllers\Controller;
use App\Models\Admin\Account;
use App\Models\Admin\AccountTransaction;
use App\Models\SadikLog;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {                    
        return view('admin.account.index');
    }

    public function datatable()
    {

        if (request()->ajax()) {
            
            $models = Account::groupBy('category')
                    ->selectRaw('id, count(*) as total, category');
                

            return Datatables::of($models)
                ->addIndexColumn()

                ->editColumn('category', function ($model) {
                    return toWord($model->category);
                })

                ->addColumn('count', function ($model) {

                   return $model->total;
                })

                ->editColumn('action', function ($model) {
                    return view('admin.account.action', compact('model'));
                })
                ->rawColumns(['category,action'])->make(true);
        }
    }



    public function table($id)
    {
        if (request()->ajax()) {
            $ips = Account::where('category',$id)->get();

            return Datatables::of($ips)
                ->addIndexColumn()
                ->editColumn('amount', function ($model) {
                    $debit = $model->account->where('type',"Debit")->sum('amount');
                    $credit = $model->account->where('type',"Credit")->sum('amount');
                    $data = dabit_credit($debit , $credit);
                    return $data;
                })
                ->editColumn('status', function ($model) {
                    if ($model->status == 'Active') {
                        $output = '<span class="badge badge-success">Active</span>';
                    } else {
                        $output = '<span class="badge badge-danger">InActive</span>';
                    }

                    return $output;
                })
                
                ->editColumn('action', function ($model) {
                    return view('admin.account.account-action', compact('model'));
                })
                
                ->rawColumns(['status','action', 'amount'])->make(true);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $request->validate([
                'category' => 'required',
                'account_name' => 'required',
            ]);

        $model = new Account;
        $model->category = $request->category;
        $model->name = $request->account_name;
        $model->display_name = $request->display_name;
        $model->alias = $request->alias;
        $model->phone = $request->phone;
        $model->email = $request->email;
        $model->salary = $request->salary;
        $model->address = $request->address;
        $model->account_no = $request->account_no;
        $model->check_form = $request->check_form;
        $model->check_to = $request->check_to;
        $model->opening_date = $request->opening_date;
        $model->status = 'Active';
        $model->save();

        \SadikLog::addToLog('Created a Account - ' . $request->account_name . '.');

        return response()->json(['status' => 'success', 'message' => 'New Account is stored successfully']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return view('admin.account.table', compact('id'));
    }

    public function show_data($id)
    {
        $model = Account::with('account')->findOrFail($id);
        return view('admin.account.show', compact('model'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $model = Account::findOrFail($id);
        return view('admin.account.edit', compact('model'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'category' => 'required',
            'account_name' => 'required',
        ]);

        $model = Account::findOrFail($id);
        $model->name = $request->account_name;
        $model->display_name = $request->display_name;
        $model->alias = $request->alias;
        $model->phone = $request->phone;
        $model->email = $request->email;
        $model->salary = $request->salary;
        $model->address = $request->address;
        $model->account_no = $request->account_no;
        $model->check_form = $request->check_form;
        $model->check_to = $request->check_to;
        $model->opening_date = $request->opening_date;
        $model->status = $request->status;
        $model->save();

        \SadikLog::addToLog('updated a Account - ' . $request->account_name . '.');

        return response()->json(['status' => 'success', 'message' => 'Account updated successfully']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $model = Account::findOrFail($id);
        $account_id = $model->id;
        $accounts = AccountTransaction::where('account_id', $account_id)->get();
        if(count($accounts) == 0){
            foreach ($accounts as $account) {
                $account->delete();
            }
            $model->delete();
        }else{
            throw ValidationException::withMessages(['message' => 'Account Cannot be deleted because This Account has already Transaction']);
        }

        \SadikLog::addToLog('Deleted a Account - ' . $model->name);

        return response()->json(['status' => 'success', 'message' => 'Account is deleted successfully']);
    }
}
