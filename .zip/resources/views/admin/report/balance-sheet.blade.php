@extends('layouts.main', ['title' => (' Balance Sheet Report'), 'modal' => 'xl',])

@push('admin.css')

@endpush

@section('header')
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1> Balance Sheet Report</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="{{ url('/home') }}"><i class="fa fa-home"
                                aria-hidden="true"></i></a></li>
                    <li class="breadcrumb-item active"> Balance Sheet Report</li>
                </ol>
            </div>
        </div>
    </div>
</section>
@endsection

@section('content')
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Balance Sheet Report Show</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">

            <div class="row">

                {{-- Liabilities --}}
                <div class="col-md-6">
                    <h3 class="text-center">Liabilities</h3>
                    <hr style="border: 1px solid green">

                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <tbody>
                            @php
                                $total_liabilites = 0;
                            @endphp
                            @foreach($liabilities as $key=>$v)
                                @php
                                    $v = $v < 0 ? $v * -1 : $v;
                                    $total_liabilites += $v;
                                @endphp
                                <tr>
                                    <td>{{ toWord($key) }}</td>
                                    <td class="text-right">{{ number_format($v, 2) }}</td>
                                </tr>
                            @endforeach

                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Liabilities (Total)</th>
                                    <th class="text-right"> {{ number_format($total_liabilites, 2) }}</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                </div>
                {{-- Assets --}}
                <div class="col-md-6">
                    <h3 class="text-center">Assets</h3>
                    <hr style="border: 1px solid green">

                    <div class="table-responsive">
                        <table class="table table-hover table-bordered table-sm">
                            <tbody>
                            @php
                            $total_asset = 0;
                            @endphp
                            @foreach($asset as $key=>$v)
                                @php
                                    $v = $v < 0 ? $v * -1 : $v;
                                    $total_asset += $v;
                                @endphp
                                <tr>
                                    <td>{{ toWord($key) }}</td>
                                    <td class="text-right">{{ number_format($v, 2) }}</td>
                                </tr>
                            @endforeach

                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Assets (Total)</th>
                                    <th class="text-right">{{number_format($total_asset, 2)}}</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                </div>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
@endsection

@push('admin.scripts')
<script src="{{ asset('js/pages/vaucher.js') }}"></script>

@endpush
