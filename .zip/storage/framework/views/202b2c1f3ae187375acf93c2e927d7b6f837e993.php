<tr>
	<td>
		<input type="hidden" name="vehicle_id[]" value="<?php echo e($vehicle->id); ?>" class="pid">
		<?php echo e($vehicle->model_no); ?> (<?php echo e($vehicle->type->name); ?>)
	</td>
	<td>
		<input type="hidden" name="description[]" value="<?php echo e($description); ?>" class="qty">
		<?php echo e($description); ?>

	</td>
	<td>
		<input type="hidden" name="amount[]" value="<?php echo e($amount); ?>">
		<?php echo e($amount); ?>

	</td>
	<td>
		<input type="hidden" name="type[]" value="<?php echo e($type); ?>">
		<?php echo e($type); ?>

	</td>
	<td>
		<input type="hidden" name="date[]" value="<?php echo e($date); ?>">
		<?php echo e($date); ?>

	</td>
	
	<td>
		<button type="button" name="remove" class="btn btn-danger btn-sm remmove"><i class="fa fa-trash"></i></button>
	</td>
</tr><?php /**PATH E:\Laravel\inventory\resources\views/admin/vehicle/transaction/itemlist.blade.php ENDPATH**/ ?>