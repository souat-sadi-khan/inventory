
<?php $__env->startSection('main_voucher'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2 my-auto">
            <img src="<?php echo e(get_option('logo') && get_option('logo') != '' ? asset('storage/images/logo'). '/'. get_option('logo') : asset('images/logo.png')); ?>" class="w-100" alt="" width="90">
        </div>
        <div class="col-md-10 text-center">
            <p class="mb-"> <?php echo e(get_option('institute_top_header')); ?></p>
            <p class="h1"> <?php echo e(get_option('company_name')); ?> </p>
            <p class=" mb-0"> <?php echo e(get_option('description')); ?> </p>
        </div>
        <div class="col-md-12 text-center">
            <div class="border-one">
                <p class="mb-0  text-light"> ফোনঃ <?php echo e(get_option('alternate_phone')); ?> , মোবাইলঃ <?php echo e(get_option('phone')); ?></p>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-md-4">
            <p> ভাউচার নং ঃ <?php echo e($model->reff_no); ?> </p>
        </div>
        <div class="col-md-4 text-center">
            <span class="h3 border-two rounded-pill py-1 px-2"> আয় ভাউচার </span>
        </div>
        <div class="col-md-4 text-right">
            <div>
                <span class="mb-2"> তারিখঃ </span>
                <table class="table table-bordered d-inline border-0">
                    <tbody>
                        <tr>
                            <td class="py-1"><?php echo e(date('d')); ?></td>
                            <td class="py-1"><?php echo e(date('m')); ?></td>
                            <td class="py-1"><?php echo e(date('Y')); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="mt-1">
                <span class=""> বারঃ </span>
                <table class="table table-bordered d-inline border-0">
                    <tbody>
                        <tr>
                            <td class="py-1"> <?php echo e(date('D')); ?> </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="container mt-3">
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered border-0">
                <tbody>
                    <tr>
                        <th class="py-1" scope="row"> Voucher <span class="float-right"> : </span> </th>
                        <td class="py-1"> আয় ভাউচার </td>
                    </tr>
                    
                </tbody>
            </table>
        </div>
    </div>
    <div class="row mt-5">
        <div class="col-md-12">
            <table class="table table-bordered border-0">
                
                <tbody>
                    <tr class="c-table">
                        <td colspan="3">Transaction ID</td>
                        <td><?php echo e($model->id); ?></td>
                    </tr>
                    <tr class="c-table">
                        <td colspan="3">Account</td>
                        <td><?php echo e($model->account ? $model->account->name : ''); ?></td>
                    </tr>
                    <tr class="c-table">
                        <td colspan="3">Amount</td>
                        <td><?php echo e(number_format($model->amount, 2)); ?></td>
                    </tr>
                </tbody>
                
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.voucher',['title' => ('Print Vouchers'), 'url' => null,], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/vaucher/print/income_print.blade.php ENDPATH**/ ?>