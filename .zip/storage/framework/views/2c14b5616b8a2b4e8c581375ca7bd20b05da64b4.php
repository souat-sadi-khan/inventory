
<?php $__env->startSection('main_invoice'); ?>
<div class="container">
	<div class="row mt-5">
		<div class="col-md-2 my-auto">
			<img src="Logo2.png" class="w-100" alt="">
		</div>
		<div class="col-md-10 text-center">
			<p class="mb-"> বিসমিল্লাহির রাহমানির রাহিম </p>
			<p class="h1"> মেসার্স জনতা অটো রাইস মিল </p>
			<p class=" mb-0"> লিংক রোড, প্রধান সড়ক, কক্সবাজার </p>
		</div>
		<?php
			$date =explode('-',$model->date);
		?>
		<div class="col-md-12 text-center mt-3">
			<div class="bg-primary py-2">
				<p class="mb-0  text-light"> ফোনঃ 01856442024 , মোবাইলঃ 01856442024</p>
			</div>
		</div>
	</div>
	<div class="row mt-4 mx-5">
		<div class="col-md-4">
			<p>  নং : <?php echo e($model->reference_no); ?> </p>
		</div>
		
		<div class="col-md-4 text-right ml-auto">
			<div>
				<span class="mb-2"> তারিখঃ </span>
				<table class="table table-bordered d-inline border-0">
					<tbody>
						<tr>
							<td class="py-1"><?php echo e($date[2]); ?></td>
							<td class="py-1"><?php echo e($date[1]); ?></td>
							<td class="py-1"><?php echo e($date[0]); ?></td>
						</tr>
					</tbody>
				</table>
			</div>
			
		</div>
	</div>
</div>
<div class="container mt-3">
	<div class="row mx-5">
		<div class="col-md-12">
			<table class="table table-bordered border-0">
				<tbody>
					<tr>
						<th class="py-1" scope="row"> নাম <span class="float-right"> : </span>  </th>
						<td class="py-1"><?php echo e($model->customer?$model->customer->customer_name:''); ?> </td>
					</tr>
					<tr>
						<th class="py-1" scope="row"> মোবাইল <span class="float-right"> : </span>  </th>
						<td class="py-1"><?php echo e($model->customer?$model->customer->customer_mobile:''); ?> </td>
					</tr>
					
					<tr class="my-1">
						<th class="py-1" scope="row"> ঠিকান <span class="float-right"> : </span> </th>
						<td class="py-1"> <?php echo e($model->customer?$model->customer->customer_address:''); ?> </td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<div class="row mt-5 mx-5">
		<div class="col-md-12">
			<table class="table table-bordered border-0">
				<thead class="bg-primary text-black">
					<tr>
						<th class="w-50" scope="col"> বিবরণ </th>
						<th class="w-2" scope="col"> পরিমাণ </th>
						<th class="w-2" scope="col"> দর </th>
						<th class="w-2" scope="col"> টাকা </th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $model->sell_lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($product->product->product_name); ?></td>
						<td><?php echo e($product->quantity); ?></td>
						<td><?php echo e($product->unit_price); ?>  <?php echo e(get_option('currency_symbol')); ?></td>
						<td><?php echo e($product->total); ?> <?php echo e(get_option('currency_symbol')); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				<tfoot>
				<tr>
					<td class="border-0"> </td>
					<td class="border-0"></td>
					<td class="py-1"> মোট </td>
					<td><?php echo e($model->sub_total); ?> <?php echo e(get_option('currency_symbol')); ?></td>
				</tr>
				<?php if($model->discount_amount): ?>
				<tr>
					<td class="border-0"> </td>
					<td class="border-0"></td>
					<td class="py-1"> ডিসকাউন্ট </td>
					<td><?php echo e($model->discount_amount); ?> <?php echo e(get_option('currency_symbol')); ?></td>
				</tr>
				<?php endif; ?>
				<?php if($model->tax): ?>
				<tr>
					<td class="border-0"> </td>
					<td class="border-0"></td>
					<td class="py-1"> কর </td>
					<td><?php echo e($model->tax); ?> <?php echo e(get_option('currency_symbol')); ?></td>
				</tr>
				<?php endif; ?>
				<?php if($model->shipping_charges): ?>
				<tr>
					<td class="border-0"> </td>
					<td class="border-0"></td>
					<td class="py-1"> বহন খরচ </td>
					<td><?php echo e($model->shipping_charges); ?> <?php echo e(get_option('currency_symbol')); ?></td>
				</tr>
				<?php endif; ?>
				
				<tr>
					<td class="border-0"> </td>
					<td class="border-0"></td>
					<td class="py-1"> মোট প্রদেয় </td>
					<td><?php echo e($model->net_total); ?> <?php echo e(get_option('currency_symbol')); ?></td>
				</tr>
				<tr>
					<td class="border-0"> </td>
					<td class="border-0"></td>
					<td class="py-1"> মোট দেওয়া </td>
					<td><?php echo e($model->paid); ?> <?php echo e(get_option('currency_symbol')); ?></td>
				</tr>
				<tr>
					<td class="border-0 py-1" colspan="2"> কথায়ঃ <?php echo e(convert_number_to_words($model->net_total)); ?> </td>
					<td class="py-1"> বাকী </td>
					<td><?php echo e($model->due); ?> <?php echo e(get_option('currency_symbol')); ?></td>
				</tr>
				</tfoot>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.invoice',['title' => ('Print Invoice'), 'url' => route('admin.sale_voucher.sale.create'),], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/sale/partial/view.blade.php ENDPATH**/ ?>