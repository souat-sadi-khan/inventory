<form action="<?php echo e(route('admin.vehicle.update', $model->id)); ?>" method="post" id="modal_form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    <div class="row">


        
        <div class="col-md-6 form-group">
            <label for="vehicle_type_id">Vehicle Type <span class="text-danger">*</span></label>
            <select data-parsley-errors-container="#Vehicle_type_save_error" required name="vehicle_type_id"
                id="vehicle_type_id" class="form-control select" data-placeholder="Select Vehicle Type">
                <option value="">Select Vehicle Type </option>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e($type->id == $model->vehicle_type_id?'selected':''); ?> value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <span id="Vehicle_type_save_error"></span>
        </div>

               
            <div class="col-md-6 form-group">
                <label for="name"> Vehicle Name <span class="text-danger">*</span>
                </label>
                <input type="text" value="<?php echo e($model->name); ?>" name="name" id="name" class="form-control"
                    placeholder="Enter Vehicle Name" required>
            </div>

        
        <div class="col-md-6 form-group">
            <label for="regi_no"> Registrarion Number <span class="text-danger">*</span>
            </label>
            <input type="text" value="<?php echo e($model->regi_no); ?>" name="regi_no" id="regi_no" class="form-control"
                placeholder="Enter Registrarion Number" required>
        </div>

        
        <div class="col-md-6 form-group">
            <label for="chassis_no"> Chassis Number <span class="text-danger">*</span>
            </label>
            <input type="text" value="<?php echo e($model->chassis_no); ?>" name="chassis_no" id="chassis_no" class="form-control"
                placeholder="Enter Chassis Number">
        </div>

        
        <div class="col-md-6 form-group">
            <label for="model_no"> Model Number <span class="text-danger">*</span>
            </label>
            <input type="text" value="<?php echo e($model->model_no); ?>" name="model_no" id="model_no" class="form-control"
                placeholder="Enter Model Number" required>
        </div>

        
        <div class="col-md-6 form-group">
            <label for="engine_no"> Engine Number <span class="text-danger">*</span>
            </label>
            <input type="text" value="<?php echo e($model->engine_no); ?>" name="engine_no" id="engine_no" class="form-control"
                placeholder="Enter Engine Number">
        </div>


        
        <div class="col-md-6 form-group">
            <label for="license_no"> License Number <span class="text-danger">*</span>
            </label>
            <input type="text" name="license_no" value="<?php echo e($model->license_no); ?>" id="license_no" class="form-control" placeholder="Enter License Number"
            >
        </div>

        
        <div class="col-md-6 form-group">
            <label for="license_validity"> License Validity <span class="text-danger">*</span>
            </label>
            <input type="text" name="license_validity" value="<?php echo e($model->license_validity); ?>" id="license_validity" class="form-control"
                placeholder="Enter License Validity">
        </div>


        
        <div class="col-md-6 form-group">
            <label for="road_permit"> Road Permit <span class="text-danger">*</span>
            </label>
            <input type="text" name="road_permit" value="<?php echo e($model->road_permit); ?>" id="road_permit" class="form-control" placeholder="Enter Road Permit"
            >
        </div>

        
        <div class="col-md-6 form-group">
            <label for="investment"> Total Investment <span class="text-danger">*</span>
            </label>
            <input type="number" name="investment" value="<?php echo e($model->investment); ?>" id="investment" class="form-control"
                placeholder="Enter Total Investment" required>
        </div>


        
        <div class="col-md-6 form-group">
            <label for="status">Status <span class="text-danger">*</span></label>
            <select data-parsley-errors-container="#Vehicles_status_save_error" required name="status" id="status"
                class="form-control select" data-placeholder="Select Vehicle Status">
                <option <?php echo e($model->status =='Active'?'selected':''); ?> value="Active">Active</option>
                <option <?php echo e($model->status =='InActive'?'selected':''); ?> value="InActive">InActive</option>
            </select>
            <span id="Vehicles_status_save_error"></span>
        </div>



    </div>

    <button type="submit" id="submit" class="btn btn-primary float-right px-5">Submit</button>
    <button type="button" id="submiting" class="btn btn-sm btn-info float-right px-5" id="submiting"
        style="display: none;">
        <i class="fa fa-spinner fa-spin fa-fw"></i>Loading...</button>

    <button type="button" class="btn btn-sm btn-danger" id="close">Close</button>
</form>
<?php /**PATH E:\Laravel\inventory\resources\views/admin/vehicle/vehicle/edit.blade.php ENDPATH**/ ?>