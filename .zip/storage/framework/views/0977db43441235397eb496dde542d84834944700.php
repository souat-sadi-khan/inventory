<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.update')): ?>
    <button id="content_managment" data-url="<?php echo e(route('admin.product-initiazile.category.edit',$model->id)); ?>" title="Edit <?php echo e($model->category_name); ?>" class="btn btn-sm btn-info"><i class="fa fa-pencil-square-o"></i></button>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.delete')): ?>
    <button id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.product-initiazile.category.destroy',$model->id)); ?>" title="Delete <?php echo e($model->category_name); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?>
<?php /**PATH E:\Laravel\inventory\resources\views/admin/product/category/action.blade.php ENDPATH**/ ?>