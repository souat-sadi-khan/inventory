<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Vehicle's Full View Information</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="row">
                
                <div class="col-md-6 card card-success">
                    <div class="card-header">
                        <h3 class="card-title">Basic Information</h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fa fa-plus"></i></button>
                        </div>
                    </div>
                    <div class="card-body px-0">
                        <div class="bg-light p-1">
                            <?php if($model->type->name != ''): ?>
                            <h4 class="text-center">Name : <?php echo e($model->type->name); ?> (<?php echo e($model->model_no); ?>) </h4>
                            <?php endif; ?>
                            <?php if($model->regi_no != ''): ?>
                            <h6 class="text-center">Registration No : <?php echo e($model->regi_no); ?> </h6>
                            <?php endif; ?>
                            <?php if($model->chassis_no != ''): ?>
                            <h6 class="text-center">Chassis Number  : <?php echo e($model->chassis_no); ?> </h6>
                            <?php endif; ?>
                            <?php if($model->model_no != ''): ?>
                            <h6 class="text-center">Model Number : <?php echo e($model->model_no); ?> </h6>
                            <?php endif; ?>
                            <?php if($model->engine_no != ''): ?>
                            <h6 class="text-center">Engine Number : <?php echo e($model->engine_no); ?> </h6>
                            <?php endif; ?>
                            <?php if($model->road_permit != ''): ?>
                            <h6 class="text-center">License Number : <?php echo e($model->road_permit); ?> </h6>
                            <?php endif; ?>
                            <?php if($model->license_no != ''): ?>
                            <h6 class="text-center">License Validity : <?php echo e($model->license_no); ?> </h6>
                            <?php endif; ?>
                            <?php if($model->license_validity != ''): ?>
                            <h6 class="text-center">Road Permit : <?php echo e($model->license_validity); ?> </h6>
                            <?php endif; ?>
                            <?php if($model->investment != ''): ?>
                            <h6 class="text-center">Total Investment : <?php echo e($model->investment); ?> </h6>
                            <?php endif; ?>
                            <?php if($model->status != ''): ?>
                            <h6 class="text-center">Status : <?php echo e($model->status); ?> </h6>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="info-box col-md-6">
                    <span class="info-box-icon bg-info"><?php echo e(get_option('currency_symbol')); ?></span>
                    
                    <div class="info-box-content">
                        <h4 class="info-box-text text-center">Balance Info</h4>
                        <h6 class="info-box-number text-center">
                        <strong><?php echo app('translator')->get('Total Investment'); ?></strong>
                        <p class="text-muted">
                            <span class="display_currency" data-currency_symbol="true">
                            <?php echo e($model->investment); ?> <?php echo e(get_option('currency_symbol')); ?></span>
                        </p>
                        <strong><?php echo app('translator')->get('Total Income'); ?></strong>
                        <p class="text-muted">
                            <span class="display_currency" data-currency_symbol="true">
                            <?php echo e($income); ?> <?php echo e(get_option('currency_symbol')); ?></span>
                        </p>
                        <strong><?php echo app('translator')->get('Total Expence'); ?></strong>
                        <p class="text-muted">
                            <span class="display_currency" data-currency_symbol="true">
                            <?php echo e($expence); ?> <?php echo e(get_option('currency_symbol')); ?></span>
                        </p>
                        <strong><?php echo app('translator')->get('Current Due'); ?></strong>
                        <p class="text-muted">
                            <span class="display_currency" data-currency_symbol="true">
                            <?php echo e($balance); ?> <?php echo e(get_option('currency_symbol')); ?></span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.card-body -->
    </div>


        <div class="card">
        <div class="card-header">
            <h3 class="card-title">Vehicle Transaction</h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped " >
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('id'); ?></th>
                        <th><?php echo app('translator')->get('Transaction Type'); ?></th>
                        <th><?php echo app('translator')->get('Description'); ?></th>
                        <th><?php echo app('translator')->get('Amount'); ?></th>
                        <th><?php echo app('translator')->get('Date'); ?></th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $model->invest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($item->type); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td><?php echo e($item->amount); ?></td>
                        <td><?php echo e($item->date); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
                
            </table>
        </div>
    </div>
<?php /**PATH E:\Laravel\inventory\resources\views/admin/vehicle/vehicle/show.blade.php ENDPATH**/ ?>