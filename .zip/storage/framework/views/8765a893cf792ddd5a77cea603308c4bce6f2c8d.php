<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fa fa-bars"></i></a>
        </li>
        
    </li>
    
    
</ul>
<!-- SEARCH FORM -->

<!-- Right navbar links -->
<ul class="navbar-nav ml-auto">
    <!-- Messages Dropdown Menu -->
   <!--  <li class="nav-item dropdown">
       <a class="nav-link" data-toggle="dropdown" href="#">
           <i class="fa fa-comments"></i>
           <span class="badge badge-danger navbar-badge">3</span>
       </a>
       <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
           
           <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
       </div>
   </li>
   Notifications Dropdown Menu
   <li class="nav-item dropdown">
       <a class="nav-link" data-toggle="dropdown" href="#">
           <i class="fa fa-bell"></i>
           <span class="badge badge-warning navbar-badge">15</span>
       </a>
       <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
           <span class="dropdown-item dropdown-header">15 Notifications</span>
           <div class="dropdown-divider"></div>
           <a href="#" class="dropdown-item">
               <i class="fa fa-file mr-2"></i> 3 new reports
               <span class="float-right text-muted text-sm">2 days</span>
           </a>
           <div class="dropdown-divider"></div>
           <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
       </div>
   </li> -->
    <!-- User Account: style can be found in dropdown.less -->
    <li class="dropdown nav-item user user-menu">
        <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
            <img src="<?php echo e((Auth::user()->image != 'user.png' ? asset('storage/images/user'. '/'. Auth::user()->image) : asset('images/user.png'))); ?>" class="user-image" alt="User Image">
            <span class="hidden-xs"><?php echo e(substr(Auth::user()->name, 0 , 15)); ?></span>
        </a>
        <ul class="dropdown-menu">
            <!-- User image -->
            <li class="user-header">
                <img src="<?php echo e((Auth::user()->image != 'user.png' ? asset('storage/images/user'. '/'. Auth::user()->image) : asset('images/user.png'))); ?>" class="img-circle" alt="User Image">
                <p>
                    <?php
                    $user_id = Auth::user()->id;
                    $user = App\User::where('id', $user_id)->with('info')->first();
                    ?>
                    <?php echo e(Auth::user()->name); ?> - <?php echo e($user->info->designation); ?>

                    <small>Member since <?php echo e(formatDate(Auth::user()->created_at)); ?></small>
                </p>
            </li>

            <!-- Menu Footer-->
            <li class="user-footer">
                <div class="pull-left">
                    <a href="<?php echo e(route('admin.me')); ?>" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                    <a id="logout" data-url='<?php echo e(route('logout')); ?>' class="btn btn-default btn-flat">Sign out</a>
                </div>
            </li>
        </ul>
    </li>





</ul>
</nav>
<?php /**PATH E:\Laravel\inventory\resources\views/_partials/admin/navbar.blade.php ENDPATH**/ ?>