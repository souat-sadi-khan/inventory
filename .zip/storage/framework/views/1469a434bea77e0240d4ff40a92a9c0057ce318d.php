<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle-transaction.update')): ?>
    <button title="Update <?php echo e($model->name); ?> Information" id="content_managment" data-url="<?php echo e(route('admin.vehicle-transaction.edit',$model->id)); ?>"  class="btn btn-sm btn-info"><i class="fa fa-pencil-square-o"></i></button>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vehicle-transaction.delete')): ?>
    <button title="Delete <?php echo e($model->name); ?>" id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.vehicle-transaction.destroy',$model->id)); ?>"  class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/vehicle/transaction/action.blade.php ENDPATH**/ ?>