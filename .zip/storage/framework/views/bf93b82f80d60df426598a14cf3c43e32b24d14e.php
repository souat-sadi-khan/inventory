

<?php $__env->startPush('admin.css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/datatable/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/datatable/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/datatable/css/buttons.bootstrap4.min.css')); ?>">
    <style>
        .table th, .table td {
         padding: 0.2rem 0.5rem;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header'); ?>
 <a href="<?php echo e(route('admin.general.settings')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-cog fa-spin" aria-hidden="true"></i><?php echo app('translator')->get('Setting'); ?></a>
    <a href="<?php echo e(route('today')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-cc-diners-club" aria-hidden="true"></i><?php echo app('translator')->get('Today'); ?></a>
    <a href="https://www.youtube.com/channel/UC02AhNHwgb5C3FGvzo9U0Wg" target="_blank" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-youtube-play" aria-hidden="true"></i><?php echo app('translator')->get('Tutorial'); ?></a>
    <a href="https://sattit.com/" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-question-circle" aria-hidden="true"></i><?php echo app('translator')->get('Help'); ?></a>
    <a href="<?php echo e(route('admin.sale_voucher.sale.create',['sale_type'=>'wholesale'])); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-bath" aria-hidden="true"></i><?php echo app('translator')->get('Whole Sale'); ?></a>
    <a href="<?php echo e(route('admin.sale_voucher.sale.create',['sale_type'=>'retail'])); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-bath" aria-hidden="true"></i><?php echo app('translator')->get('Retail Sale'); ?></a>
    <a href="<?php echo e(route('admin.sale_voucher.return.create')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-retweet" aria-hidden="true"></i><?php echo app('translator')->get('Return'); ?></a>
    <a href="<?php echo e(route('admin.sale_voucher.return.index')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-list-alt" aria-hidden="true"></i><?php echo app('translator')->get('Return List'); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-md-3">
                    <label for="customer_id">Customer</label>
                        <select name="customer_id" id="customer_id" class="form-control select" >
                         <option value="">All</option>
                         <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($element->id); ?>"><?php echo e($element->customer_name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </select>
                </div>

                <div class="col-md-3">
                    <label for="created_by">Sold By</label>
                        <select name="created_by" id="created_by" class="form-control select" >
                            <option value="">All</option>
                         <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($element->id); ?>"><?php echo e($element->email); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </select>
                </div>

                <div class="col-md-3">
                    <label for="payment_status">Payment Status</label>
                        <select name="payment_status" id="payment_status" class="form-control select" >
                            <option value="">All</option>
                         <option value="paid">Paid</option>
                         <option value="due">Due</option>
                         <option value="partial">Partial</option> 
                        </select>
                </div>

                 <div class="col-md-3">
                    <label for="sale_type">Sale Type</label>
                        <select name="sale_type" id="sale_type" class="form-control select" >
                            <option value="">All</option>
                         <option value="retail">Retail</option>
                         <option value="wholesale">WholeSale</option>
                        </select>
                </div>

            </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div id="accordion">
                <div class="card card-primary">
                    <a class="bg-primary">
                        <div class="card-header">
                            <h4 class="card-title">
                                Sale List
                            </h4>
                        </div>
                    </a>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered content_managment_table" data-url="<?php echo e(route('admin.sale_voucher.sale.index')); ?>">
                                    <thead>
                                        <tr>
                                            <th><?php echo app('translator')->get('Date'); ?></th>
                                            <th><?php echo app('translator')->get('Ref'); ?></th>
                                            <th><?php echo app('translator')->get('Customer'); ?></th>
                                            <th style="width: 16%"><?php echo app('translator')->get('Payment Status'); ?></th>
                                            <th><?php echo app('translator')->get('Total Amount'); ?></th>
                                            <th><?php echo app('translator')->get('Total Paid'); ?></th>
                                            <th><?php echo app('translator')->get('Due'); ?></th>
                                            <th><?php echo app('translator')->get('Return'); ?></th>
                                            <th><?php echo app('translator')->get('action'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th><?php echo app('translator')->get('Date'); ?></th>
                                            <th><?php echo app('translator')->get('Ref'); ?></th>
                                            <th><?php echo app('translator')->get('Customer'); ?></th>
                                            <th style="width: 16%"><?php echo app('translator')->get('Payment Status'); ?></th>
                                            <th><?php echo app('translator')->get('Total Amount'); ?></th>
                                            <th><?php echo app('translator')->get('Total Paid'); ?></th>
                                            <th><?php echo app('translator')->get('Due'); ?></th>
                                            <th><?php echo app('translator')->get('Return'); ?></th>
                                            <th><?php echo app('translator')->get('action'); ?></th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                </div>
            </div>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin.scripts'); ?>
<script src="<?php echo e(asset('assets/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/datatable/js/buttons.html5.min.js')); ?>"></script>

<script>
    var emran = "";
            $.extend($.fn.dataTable.defaults, {
            autoWidth: false,
            responsive: true,
            dom: '<"datatable-header"fl><"datatable-scroll-wrap"t><"datatable-footer"ip>',
            language: {
                search: '<span>Filter:</span> _INPUT_',
                searchPlaceholder: 'Type to filter...',
                processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ',
                lengthMenu: '<span>Show:</span> _MENU_',
                paginate: {
                    'first': 'First',
                    'last': 'Last',
                    'next': $('html').attr('dir') == 'rtl' ? '&larr;' : '&rarr;',
                    'previous': $('html').attr('dir') == 'rtl' ? '&rarr;' : '&larr;'
                }
            }
        });
        emran = $('.content_managment_table').DataTable({
            responsive: {
                details: {
                    type: 'column',
                    target: 'tr'
                }
            },
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'copyHtml5',
                    text: '<i class="fa fa-clipboard" aria-hidden="true"></i>',
                    className: 'btn btn-sm btn-outline-info',
                    footer: true
                },
                {
                    extend: 'excelHtml5',
                    text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i>',
                    className: 'btn btn-sm btn-outline-info',
                    footer: true
                },
                {
                    extend: 'csvHtml5',
                    text: '<i class="fa fa-table" aria-hidden="true"></i>',
                    className: 'btn btn-sm btn-outline-info',
                    footer: true
                },
                {
                    extend: 'pdfHtml5',
                    text: '<i class="fa fa-file-pdf-o" aria-hidden="true"></i>',
                    className: 'btn btn-sm btn-outline-info',
                    footer: true
                },
                {
                    extend: 'print',
                    text: '<i class="fa fa-print" aria-hidden="true"></i>',
                    className: 'btn btn-sm btn-outline-info',
                    footer: true
                },
            ],

            columnDefs: [{
                width: "80px",
                targets: [0]
            }, {
                orderable: false,
                targets: [7]
            }],

            order: [0, 'desc'],
            processing: true,
            serverSide: true,
           ajax: { 
            url: $('.content_managment_table').data('url'),
            data: function(d) {
                d.customer_id = $('select#customer_id').val();
                d.created_by = $('select#created_by').val();
                d.payment_status = $('select#payment_status').val();
                d.sale_type = $('select#sale_type').val();
            },
          },
              columns: [
                // { data: 'checkbox', name: 'checkbox' },
               {
                    data: 'date',
                    name: 'date'
                }, {
                    data: 'reference_no',
                    name: 'reference_no'
                }, {
                    data: 'customer',
                    name: 'customer'
                }, {
                    data: 'payment_status',
                    name: 'payment_status'
                }, {
                    data: 'net_total',
                    name: 'net_total'
                }, {
                    data: 'paid',
                    name: 'paid'
                }, {
                    data: 'due',
                    name: 'due'
                },{
                    data: 'return',
                    name: 'return'
                }, {
                    data: 'action',
                    name: 'action'
                }
            ]

        });

      $('select#customer_id, select#created_by, select#payment_status, select#sale_type').on(
        'change',
        function() {
            emran.ajax.reload();
        }
    );
 _componentSelect2Normal();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', ['title' => ('Sale List'), 'modal' => 'xl',], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/sale/index.blade.php ENDPATH**/ ?>