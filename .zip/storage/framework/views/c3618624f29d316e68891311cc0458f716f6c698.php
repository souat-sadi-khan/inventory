<tr>
	<td>
		<input type="hidden" name="variation[<?php echo e($row); ?>][product_id]" value="<?php echo e($model->id); ?>" class="pid">
		<?php echo e($model->product_name); ?>

	</td>
	<td>
		<input type="hidden" name="variation[<?php echo e($row); ?>][quantity]" value="<?php echo e($quantity); ?>" class="qty">
		<?php echo e($quantity); ?>

	</td>
	<td>
		<input type="hidden" name="variation[<?php echo e($row); ?>][unit_price]" value="<?php echo e($product_price); ?>">
		<?php echo e($product_price); ?>

	</td>
	<td>
		<input type="hidden" name="variation[<?php echo e($row); ?>][total]" value="<?php echo e($product_price*$quantity); ?>">
		<span class="amt" id="amt"><?php echo e($product_price*$quantity); ?></span>
	</td>
	<td>
		<button type="button" name="remove" class="btn btn-danger btn-sm remmove"><i class="fa fa-trash"></i></button>
	</td>
</tr><?php /**PATH E:\Laravel\inventory\resources\views/admin/sale/partial/itemlist.blade.php ENDPATH**/ ?>