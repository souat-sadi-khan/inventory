<?php if($model->id == 1): ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('account.show')): ?>
    <a title="View <?php echo e($model->name); ?> Information" href="<?php echo e(route('admin.account.show_data',$model->id)); ?>"><button class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></button></a>
<?php endif; ?>
<?php else: ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('account.show')): ?>
    <a title="View <?php echo e($model->name); ?> Information" href="<?php echo e(route('admin.account.show_data',$model->id)); ?>"><button class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></button></a>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('account.update')): ?>
    <button title="Update <?php echo e($model->name); ?> Information" id="content_managment" data-url="<?php echo e(route('admin.account.edit',$model->id)); ?>"  class="btn btn-sm btn-info"><i class="fa fa-pencil-square-o"></i></button>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('account.delete')): ?>
    <button title="Delete <?php echo e($model->name); ?>" id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.account.destroy',$model->id)); ?>"  class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?>
<?php endif; ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/account/account-action.blade.php ENDPATH**/ ?>