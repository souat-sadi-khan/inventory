<tr>
	<td>
		<input type="hidden" name="form_bank[]" value="<?php echo e($bank->id); ?>" class="pid">
		<?php echo e($bank->name); ?>

	</td>
	<td>
		<input type="hidden" name="to_bank[]" value="<?php echo e($account->id); ?>" class="qty">
		<?php echo e($account->name); ?>

	</td>
	<td>
		<input type="hidden" name="sent_type[]" value="<?php echo e($type); ?>">
		<?php echo e($type); ?>

	</td>
	<td>
		<input type="hidden" name="sent_amount[]" value="<?php echo e($amount); ?>">
		<?php echo e($amount); ?>

	</td>
	<td>
		<button type="button" name="remove" class="btn btn-danger btn-sm remmove"><i class="fa fa-trash"></i></button>
	</td>
</tr><?php /**PATH E:\Laravel\inventory\resources\views/admin/vaucher/partial/itemlist.blade.php ENDPATH**/ ?>