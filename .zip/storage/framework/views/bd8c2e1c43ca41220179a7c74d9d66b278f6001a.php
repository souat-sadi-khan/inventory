<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('brand.update')): ?>
    <a data-url="<?php echo e(route('admin.products.products.show',$model->id)); ?>"  class="btn btn-sm btn-info btn_modal"><i class="fa fa-eye-slash" title="View"></i></a>
<?php endif; ?> 
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('brand.update')): ?>
    <a href="<?php echo e(route('admin.products.products.edit',$model->id)); ?>"  class="btn btn-sm btn-info"><i class="fa fa-pencil-square-o"></i></a>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('brand.delete')): ?>
    <button id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.products.products.destroy',$model->id)); ?>" title="Delete <?php echo e($model->brand_name); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/product/product/action.blade.php ENDPATH**/ ?>