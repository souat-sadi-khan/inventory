<?php

use App\Models\Admin\Account;
use App\Models\Customer;
use App\Models\Supplier;
use App\Setting;
use Illuminate\Database\Seeder;

class GeneralSettingSedder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //  Create default navbar top
        Setting::create([
            'name'      =>  'navbar_position',
            'value'     =>  'top',
        ]);

        // Create Log Event
        Setting::create([
            'name'      => 'log_event',
            'value'     => 'created,updated,deleted', 
        ]);

        //  Create log_delete_date
        Setting::create([
            'name'      =>  'log_delete_date',
            'value'     =>  '365',
        ]);

        //  Create log_delete_date
        Setting::create([
            'name'      =>  'log_report',
            'value'     =>  'on',
        ]);

        // ip_filter off
        Setting::create([
            'name'      =>  'ip_filter',
            'value'     =>  'off',
        ]);


        // Default Account
        Account::create([
            'category'      =>  'Cash_in_hand',
            'name'     =>  'Cash In Hand',
            'status'     =>  'Active',
        ]);

        Customer::create([
            'customer_name'      =>  'Walk_in_Customer',
            'customer_mobile'     =>  '01xxxxxxxxx',
            'customer_email'     =>  'ww@gmail.com'
            'status'     =>  true,
        ]);

        Supplier::create([
            'sup_name'      =>  'Walk_in_Supplier',
            'sup_mobile'     =>  '01xxxxxxxxx',
            'sup_email'     =>  'ws@gmail.com'
            'status'     =>  true,
        ]);
    }
}
