@extends('layouts.main', ['title' => ('Sale Payment'), 'modal' => 'xl',])
@push('admin.css')
@endpush

@section('content')
<div class="card">
 <div class="alert alert-danger text-light">
  <strong>@lang('This Page Under Design')</strong>.
</div>
</div>
@endsection
@push('admin.scripts')
<script>

</script>
@endpush