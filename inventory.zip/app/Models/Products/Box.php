<?php

namespace App\Models\Products;

use Illuminate\Database\Eloquent\Model;

class Box extends Model
{
    //
}
