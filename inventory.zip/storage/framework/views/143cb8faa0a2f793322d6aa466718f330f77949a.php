
<?php $__env->startPush('admin.css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('header'); ?>
  <a href="<?php echo e(route('admin.general.settings')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-cog fa-spin" aria-hidden="true"></i><?php echo app('translator')->get('Setting'); ?></a>
    <a href="<?php echo e(route('today')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-cc-diners-club" aria-hidden="true"></i><?php echo app('translator')->get('Today'); ?></a>
    <a href="https://www.youtube.com/channel/UC02AhNHwgb5C3FGvzo9U0Wg" target="_blank" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-youtube-play" aria-hidden="true"></i><?php echo app('translator')->get('Tutorial'); ?></a>
    <a href="https://sattit.com/" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-question-circle" aria-hidden="true"></i><?php echo app('translator')->get('Help'); ?></a>
    <a href="<?php echo e(route('admin.pur_voucher.purchase.create')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-bath" aria-hidden="true"></i><?php echo app('translator')->get('Purchase'); ?></a>
    <a href="<?php echo e(route('admin.pur_voucher.purchase.index')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-list-alt" aria-hidden="true"></i><?php echo app('translator')->get('Purchase List'); ?></a>
    <a href="<?php echo e(route('admin.pur_voucher.return.index')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-list-alt" aria-hidden="true"></i><?php echo app('translator')->get('Return List'); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-body">
     <form action="<?php echo e(route('admin.pur_voucher.return.store')); ?>" method="post" id="content_form">
     	<input type="hidden" name="transaction_id" value="<?php echo e($purchases->id); ?>">
     		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-sm-4">
						<h4>Parent Purchase</h4>
						<strong><?php echo app('translator')->get('Reference'); ?>:</strong> <?php echo e($purchases->reference_no); ?> <br>
						<strong><?php echo app('translator')->get('Date'); ?>:</strong> <?php echo e($purchases->date); ?>

					</div>
					<div class="col-sm-4">
						<strong><?php echo app('translator')->get('Supplier'); ?>:</strong> <?php echo e($purchases->supplier->sup_name); ?> <br>
						<strong><?php echo app('translator')->get('Mobile'); ?>:</strong> <?php echo e($purchases->supplier->sup_mobile); ?>

					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-4">
				<div class="form-group">
					<label for="reference_no">Reference No</label>
					<input type="text" name="reference_no" id="reference_no" class="form-control" value="<?php echo e(!empty($purchases->return_parent->reference_no) ? $purchases->return_parent->reference_no : null); ?>" readonly>
				</div>
			</div>
			<div class="clearfix"></div>
			<hr>
			<div class="col-sm-12">
				<div class="table-responsive">
				<table class="table" id="purchase_return_table" style="background: #eee">
					<thead>
						<tr class="bg-green">
							<th>#</th>
							<th><?php echo app('translator')->get('Product Name'); ?></th>
							<th><?php echo app('translator')->get('Unit Price'); ?></th>
							<th><?php echo app('translator')->get('Purchase Qty'); ?></th>
							<th><?php echo app('translator')->get('	Quantity Remaining'); ?></th>
							<th><?php echo app('translator')->get('Return Quantity'); ?></th>
							<th><?php echo app('translator')->get('Return Subtotal'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $purchases->purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase_line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
						$qty_available = $purchase_line->qty
						?>
						<tr>
							<td><?php echo e($loop->iteration); ?></td>
							<td>
								<?php echo e($purchase_line->product->product_name); ?>

							</td>
							<td><span class="display_currency" data-currency_symbol="true"><?php echo e($purchase_line->price); ?></span></td>
							<td><span class="display_currency" data-is_quantity="true" data-currency_symbol="false"><?php echo e($purchase_line->qty); ?></span></td>
							<td><span class="display_currency" data-currency_symbol="false" data-is_quantity="true"><?php echo e($qty_available-$purchase_line->quantity_returned); ?></span> 
								<input type="hidden" class="qty_available" value="<?php echo e($qty_available); ?>">
							</td>
							<td>
								<input type="text" name="returns[<?php echo e($purchase_line->id); ?>]" value="<?php echo e($purchase_line->quantity_returned); ?>"
								class="form-control input-sm input_number return_qty input_quantity">
								<span class="text-danger return_error"></span>
								<input type="hidden" class="unit_price" value="<?php echo e($purchase_line->price); ?>">
							</td>
							<td>
								<div class="return_subtotal"><?php echo e($purchase_line->quantity_returned*$purchase_line->price); ?></div>
								
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			  </div>
			</div>
		</div>
		<div class="row">
				   <div class="col-md-4">
                    <div class="form-group">
                        <label for="account_id">Account </label>
                        <select name="account_id" class="form-control select" id="account_id" required>
                            <option value="">Select Account</option>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option <?php echo e($account_id==$element->id?'selected':''); ?> value="<?php echo e($element->id); ?>"><?php echo e($element->name); ?>(<?php echo e(toWord($element->category)); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
			<div class="col-sm-12 text-right">
				<strong><?php echo app('translator')->get('ReturnTotal'); ?>: </strong>&nbsp;
				<span id="net_return">0</span>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-sm-12">
				<button type="submit" class="btn btn-primary pull-right" id="submit"><?php echo app('translator')->get('Return'); ?></button>
				<button type="button" class="btn pull-right btn-info" id="submiting" style="display: none;">
				<i class="fa fa-spinner fa-spin fa-fw"></i>Loading...</button>
			</div>
		</div>
     </form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin.scripts'); ?>
<script>
	_componentSelect2Normal();
	update_purchase_return_total();
   $(document).on('change', 'input.return_qty', function(){
		update_purchase_return_total()
	});

	function update_purchase_return_total(){
		var net_return = 0;
		$('table#purchase_return_table tbody tr').each( function(){
			var qty =$(this).find('input.return_qty');
			 if (isNaN(qty.val())) {
			    toastr.error('Please Enter Valid Quantity');
			    qty.val("");

			  }
			  else{
			    if ((qty.val() -0) > ($(this).find('input.qty_available').val()-0)) {
			      toastr.error('Sorry! this much not quantity is not available');
			      $(this).find('.return_error').text('quantity is not available')
			      qty.val($(this).find('input.qty_available').val());
			    }
			  }
			var quantity = $(this).find('input.return_qty').val();
			var unit_price = $(this).find('input.unit_price').val();
			var subtotal = quantity * unit_price;
			$(this).find('.return_subtotal').text(subtotal);
			net_return += subtotal;
		});
		var net_return_inc_tax =  net_return;
		$('span#net_return').text(net_return_inc_tax);
	}

	_formValidation();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', ['title' => ('Purchase Return'), 'modal' => 'xl',], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/purchase_return/add.blade.php ENDPATH**/ ?>