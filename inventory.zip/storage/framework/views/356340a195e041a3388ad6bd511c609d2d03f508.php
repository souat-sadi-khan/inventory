      <div class="row">
        <?php if(!empty($model->return_parent)): ?>
        <div class="col-sm-6 col-xs-6">
            <h4><?php echo app('translator')->get('Purchase Return Details'); ?>:</h4>
            <strong><?php echo app('translator')->get('Return Date'); ?>:</strong> <?php echo e($model->return_parent->date); ?><br>
            <strong><?php echo app('translator')->get('Supplier'); ?>:</strong> <?php echo e($model->supplier->sup_name??''); ?> <br>
        </div>
        <div class="col-sm-6 col-xs-6">
            <h4><?php echo app('translator')->get('Purchase Details'); ?>:</h4>
            <strong><?php echo app('translator')->get('Reference'); ?>:</strong> <?php echo e($model->reference_no); ?> <br>
            <strong><?php echo app('translator')->get('date'); ?>:</strong> <?php echo e($model->date); ?>

        </div>
        <?php else: ?>
            <div class="col-sm-6 col-xs-6">
                <h4><?php echo app('translator')->get('Purchase Return Details'); ?>:</h4>
                <strong><?php echo app('translator')->get('Return Date'); ?>:</strong> <?php echo e(@format_date($model->date)); ?><br>
                <strong><?php echo app('translator')->get('Supplier'); ?>:</strong> <?php echo e($model->supplier->sup_name ?? ''); ?> <br>
            </div>
        <?php endif; ?>
      </div>
      <br>
      <div class="row">
        <div class="col-sm-12">
          <br>
          <table class="table bg-gray">
            <thead>
              <tr class="bg-green">
                  <th>#</th>
                  <th><?php echo app('translator')->get('Product'); ?></th>
                  <th><?php echo app('translator')->get('Unit Price'); ?></th>
                  <th><?php echo app('translator')->get('Return Qty'); ?></th>
                  <th><?php echo app('translator')->get('Return SubTotal'); ?></th>
              </tr>
          </thead>
          <tbody>
              <?php
                $total_before_tax = 0;
              ?>
              <?php $__currentLoopData = $model->purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase_line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($purchase_line->quantity_returned == 0): ?>
                <?php continue; ?>
              <?php endif; ?>
              <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td>
                    <?php echo e($purchase_line->product->product_name); ?>

                  </td>
                  <td><span class="display_currency" data-currency_symbol="true"><?php echo e($purchase_line->price); ?></span></td>
                  <td><?php echo e($purchase_line->quantity_returned); ?></td>
                  <td>
                    <?php
                      $line_total = $purchase_line->price * $purchase_line->quantity_returned;
                      $total_before_tax += $line_total ;
                    ?>
                    <span class="display_currency" data-currency_symbol="true"><?php echo e($line_total); ?></span>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-6"></div>
      <div class="col-sm-6">
        <table class="table">
          <tr>
            <th><?php echo app('translator')->get('Net Total'); ?>: </th>
            <td></td>
            <td><span class="display_currency pull-right" data-currency_symbol="true"><?php echo e($total_before_tax); ?></span></td>
          </tr>
    
          <tr>
            <th><?php echo app('translator')->get('Return Total'); ?>:</th>
            <td></td>
            <td><span class="display_currency pull-right" data-currency_symbol="true" ><?php echo e($model->return_parent->net_total ??  $model->net_total); ?></span></td>
          </tr>
        </table>
      </div>
    </div><?php /**PATH E:\Laravel\inventory\resources\views/admin/purchase_return/show.blade.php ENDPATH**/ ?>