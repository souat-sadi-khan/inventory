

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer.show')): ?>
    <a title="View <?php echo e($model->customer_name); ?> Information" href="<?php echo e(route('admin.customer.show',$model->id)); ?>"><button class="btn btn-sm btn-warning"><i class="fa fa-eye"></i></button></a>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier.view')): ?>
<?php if(($model->total_sale + $model->opening_balance - $model->sale_paid - $model->opening_balance_paid)>0): ?>
    <button title="Pay Due Amount" id="content_managment" data-url="<?php echo e(route('admin.customer.make_payment',[$model->id,'type'=>'Sale'])); ?>" class="btn btn-sm btn-primary"><i class="fa fa-money"></i></button>
<?php endif; ?>   
<?php endif; ?> 
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier.view')): ?>
 <?php if(($model->total_sale_return - $model->sale_return_paid) > 0): ?>
    <button title="Receive Sale Return Due" id="content_managment" data-url="<?php echo e(route('admin.customer.make_payment',[$model->id,'type'=>'sale_return'])); ?>" class="btn btn-sm btn-primary"><i class="fa fa-money"></i></button>
 <?php endif; ?>
<?php endif; ?> 

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer.update')): ?>
    <button title="Update <?php echo e($model->customer_name); ?> Information" id="content_managment" data-url="<?php echo e(route('admin.customer.edit',$model->id)); ?>"  class="btn btn-sm btn-info"><i class="fa fa-pencil-square-o"></i></button>
<?php endif; ?> 
<?php if($model->id !=1): ?>
   <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer.delete')): ?>
    <button title="Delete <?php echo e($model->customer_name); ?>" id="delete_item" data-id ="<?php echo e($model->id); ?>" data-url="<?php echo e(route('admin.customer.destroy',$model->id)); ?>"  class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH E:\Laravel\inventory\resources\views/admin/customer/action.blade.php ENDPATH**/ ?>