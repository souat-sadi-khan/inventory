<?php if($transaction->net_total - $transaction->paid > 0): ?>
<h3><?php echo app('translator')->get('Make Payment'); ?></h3>
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('admin.post_purchase_payment')); ?>"  method="post" id="modal_form">
            <input type="hidden" name="supplier_id" value="<?php echo e($transaction->supplier_id); ?>">
            <input type="hidden" name="type" value="Debit">
            <input type="hidden" name="transaction_id" value="<?php echo e($transaction->id); ?>">
            <div class="row">
                  <div class="col-md-12">
                    <label for="payment_date">
                        <?php echo app('translator')->get('Reference'); ?>
                    </label>
                    <input type="text" class="form-control" name="payment_ref_no" value="<?php echo e(random_num('Payment')); ?>" readonly>
                </div>
                <div class="col-md-12">
                    <label for="payment_date">
                        <?php echo app('translator')->get('Date'); ?>
                    </label>
                    <input type="text" class="form-control date" name="payment_date" value="<?php echo e(date('Y-m-d')); ?>">
                </div>
                <div class="col-md-12">
                    <label for="method"><?php echo app('translator')->get('Method'); ?> </label>
                    <select name="method" class="form-control select method" style="width: 100%">
                        <option value="cash">Cash</option>
                        <option value="check">Check</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="col-md-12 reference_no" style="display:none">
                    <label for="">Reference No</label>
                    <input type="text" name="check_no" class="form-control">
                </div>
                <div class="col-md-12">
                    <label for="amount">
                        <?php echo app('translator')->get('Amount'); ?>
                    </label>
                    <input type="text" class="form-control" name="amount" id="amount" value="<?php echo e($transaction->due); ?>" required>
                     <p id="message" style="color: red;"></p>
                </div>
                <div class="col-md-12">
                    <label for="note">
                        <?php echo app('translator')->get('Note'); ?>
                    </label>
                    <textarea name="note" class="form-control" id="" placeholder="Description"></textarea>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-md-6 mx-auto text-center">
                    <button type="submit" class="btn btn-primary btn-lg w-100" id="edit_submit"><?php echo app('translator')->get('Payment'); ?></button>
                    <button type="button" class="btn btn-primary btn-lg w-100" id="edit_submiting" style="display: none;" disabled=""><?php echo app('translator')->get('Submiting'); ?>  <i class="fa fa-spinner fa-spin" style="font-size: 20px" aria-hidden="true"></i></button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php else: ?>
 <div class="alert alert-success text-light">
  <strong><?php echo app('translator')->get('This Transection has No Due'); ?></strong>.
</div>
<?php endif; ?>
<br>
<h4><?php echo app('translator')->get('Payment Info'); ?></h4>
<div class="row">
    <div class="col-md-12">
        <div class="table-responsive">
        <table class="table bg-gray">
            <tbody>
                <tr class="bg-green text-light">
                    <th>#</th>
                    <th> <?php echo app('translator')->get('Date'); ?></th>
                    <th> <?php echo app('translator')->get('Reference No'); ?></th>
                    <th> <?php echo app('translator')->get('Amount'); ?></th>
                    <th> <?php echo app('translator')->get('Payment mode'); ?></th>
                    <th> <?php echo app('translator')->get('Payment note'); ?></th>
                    <th> <?php echo app('translator')->get('Print'); ?></th>
                </tr>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($pay->payment_date); ?></td>
                    <td><?php echo e($pay->payment_ref_no); ?></td>
                    <td><?php echo e($pay->amount); ?></td>
                    <td><?php echo e($pay->method); ?></td>
                    <td><?php echo e($pay->note); ?></td>
                    <td><button class="btn btn-sm btn-primary" onclick="myFunction('<?php echo e(route("admin.pur_voucher.purchase.printpayment",$pay->id)); ?>')"><i class="fa fa-print" aria-hidden="true"></i></button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div>
</div>

<script>
 $(document).on('change','.method',function(){
        var method =$(".method").val();
        if (method=='cash') {
            $('.reference_no').hide(300);
        }
        else
        {
          $('.reference_no').show(400);  
        }
   });
   function myFunction(url) {
    window.open(url, "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=auto,left=auto,width=700,height=400");
    }
</script><?php /**PATH E:\Laravel\inventory\resources\views/admin/purchase/partial/show_payments.blade.php ENDPATH**/ ?>