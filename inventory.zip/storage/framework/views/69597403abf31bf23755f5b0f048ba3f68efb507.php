<form action="<?php echo e(route('admin.vaucher.credit_store')); ?>" method="post" id="modal_form">
    <?php echo csrf_field(); ?>
    <div class="row">
        
        <div class="col-md-4 form-group">
            <label for="credit1">Credit By A/c <span
                    class="text-danger">*</span></label>
            <select name="credit1" id="credit1" data-url="<?php echo e(route('admin.vaucher.balance_check')); ?>" required class="form-control select" data-placeholder="Select Account">
                <option value="">Select Account</option>
                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($model->id == 1 ? 'selected' : ''); ?> value="<?php echo e($model->id); ?>"><?php echo e($model->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        
        <div class="col-md-2 form-group">
            <label for="credit1_amount"> .</label>
            <input type="text" value="00.00" readonly name="credit1_amount"  id="credit1_amount" class="form-control" placeholder="Enter Payment Amount">
        </div>


        
        <div class="col-md-4 form-group">
            <label for="credit2">Credit By A/c <span
                    class="text-danger">*</span></label>
            <select name="credit2" id="credit2" data-url="<?php echo e(route('admin.vaucher.balance_check')); ?>" required class="form-control select" data-placeholder="Select Account">
                <option value="">Select Account</option>
                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e($model->id); ?>"><?php echo e($model->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        
        <div class="col-md-2 form-group">
            <label for="credit2_amount">.</label>
            <input type="text" name="credit2_amount" value="00.00" readonly  id="credit2_amount" class="form-control" placeholder="Enter Payment Amount">
        </div>


        
        <div class="col-md-6 form-group mx-auto" >
            <label for="amount">Payment Amount <span
                    class="text-danger">*</span></label>
            <input autocomplete="off" type="number" name="amount" required id="amount" class="form-control" placeholder="Enter Receipt Amount">
        </div>


                 
            <div class="col-md-12 form-group">
                <label for="note">Description
                </label>
                    <textarea name="note" class="form-control" id="note" ></textarea>
            </div>



        
        <div class="col-md-6 form-group mx-auto" >
            <label for="operation_date">Operation Date 
            </label>
            <input type="text" name="operation_date" id="operation_date"
                class="form-control take_date" value="<?php echo e(date('Y-m-d')); ?>" placeholder="Enter Operation Date">
        </div>



    </div>

    <button type="submit" id="edit_submit" class="btn btn-primary float-right px-5"><i class="fa fa-floppy-o mr-3" aria-hidden="true"></i>Save</button>
    <button type="button" id="edit_submiting" class="btn btn-sm btn-info float-right" id="submiting" style="display: none;">
        <i class="fa fa-spinner fa-spin fa-fw"></i>Loading...</button>

    <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
</form>



<script>

      $(document).on('change', '#credit1', function () {
        var value = $(this).val();
        var url = $(this).data('url');

        $.ajax({
            url: url,
            data:{value : value},
            type: 'Get',
            dataType: 'json'
        })
        .done(function(data) {
            console.log(data);
            
            $('#credit1_amount').val(data);
            
        })
    });



      $(document).on('change', '#credit2', function () {
        var value = $(this).val();
        var url = $(this).data('url');

        $.ajax({
            url: url,
            data:{value : value},
            type: 'Get',
            dataType: 'json'
        })
        .done(function(data) {
            console.log(data);
            
            $('#credit2_amount').val(data);
            
        })
    });
</script><?php /**PATH E:\Laravel\inventory\resources\views/admin/vaucher/credit.blade.php ENDPATH**/ ?>