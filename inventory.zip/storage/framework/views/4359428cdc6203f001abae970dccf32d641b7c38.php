
<?php $__env->startPush('admin.css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
 <div class="alert alert-danger text-light">
  <strong><?php echo app('translator')->get('This Page Under Design'); ?></strong>.
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin.scripts'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', ['title' => ('Purchase Payment'), 'modal' => 'xl',], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/purchase/partial/paymentPrint.blade.php ENDPATH**/ ?>