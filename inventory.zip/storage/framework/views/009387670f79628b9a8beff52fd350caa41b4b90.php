
<?php $__env->startPush('admin.css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('header'); ?>
<a href="<?php echo e(route('admin.general.settings')); ?>" class="btn btn-light border-right ml-2 py-0"><i
class="fa fa-cog fa-spin" aria-hidden="true"></i><?php echo app('translator')->get('Setting'); ?></a>
<a href="<?php echo e(route('today')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-cc-diners-club"
aria-hidden="true"></i><?php echo app('translator')->get('Today'); ?></a>
<a href="https://www.youtube.com/channel/UC02AhNHwgb5C3FGvzo9U0Wg" target="_blank"
    class="btn btn-light border-right ml-2 py-0"><i class="fa fa-youtube-play"
aria-hidden="true"></i><?php echo app('translator')->get('Tutorial'); ?></a>
<a href="https://sattit.com/" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-question-circle"
aria-hidden="true"></i><?php echo app('translator')->get('Help'); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4>Purchase Return Report</h4>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="card border border-primary">
                <div class="card-body text-center">
                    <div class="row">
                        <div class="col-sm-6">
                            <label for="date"><?php echo app('translator')->get('Start Date'); ?></label>
                            <input type="text" name="sdate" id="sdate" class="form-control take_date" value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                        <div class="col-sm-6">
                            <label for="date"><?php echo app('translator')->get('End Date'); ?></label>
                            <input type="text" name="edate" id="edate" class="form-control take_date" value="<?php echo e(date('Y-m-d')); ?>">
                        </div>
                        <div class="col-md-6 mx-auto mt-2 text-center">
                            <button type="button" id="check_it" class="btn btn-primary btn-sm w-100"><?php echo app('translator')->get('Search'); ?></button>
                            <button type="button"  class="btn btn-primary btn-sm w-100" id="checking" style="display: none;">
                            <i class="fa fa-spinner fa-spin fa-fw"></i>Searching...</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="report_data"></div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin.scripts'); ?>
<script>
_componentDatePicker();
$(document).on('click', '#check_it', function() {
    var sdate = $('#sdate').val();
    var edate = $('#edate').val();
      $('#check_it').hide();
      $('#checking').show();
     $.ajax({
            url: '/admin/get_purchase_return_report',
            data: {
                sdate: sdate,
                edate: edate
            },
            type: 'Get',
            dataType: 'html'
        })
        .done(function(data) {
          $("#report_data").html(data);
          $('#check_it').show();
          $('#checking').hide();
           toastr.success('Report Genarate');
        })
});

$(function() {
    var sdate = $('#sdate').val();
    var edate = $('#edate').val();
      $('#check_it').hide();
      $('#checking').show();
     $.ajax({
            url: '/admin/get_purchase_return_report',
            data: {
                sdate: sdate,
                edate: edate
            },
            type: 'Get',
            dataType: 'html'
        })
        .done(function(data) {
          $("#report_data").html(data);
          $('#check_it').show();
          $('#checking').hide();
           toastr.success('Report Genarate');
        })
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', ['title' => ('Purchase Return Report'), 'modal' => 'xl',], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/report/purchase/purchase_return.blade.php ENDPATH**/ ?>