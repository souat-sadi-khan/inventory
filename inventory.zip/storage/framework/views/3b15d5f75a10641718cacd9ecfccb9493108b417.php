<div class="col-md-6 mx-auto text-center mb-3 border bg-light border-info">
    <b> Opening Balance</b>
</div>
<form action="<?php echo e(route('admin.vaucher.ob_store')); ?>" method="post" id="modal_form">
    <?php echo csrf_field(); ?>
    <div class="row">
        
        <div class="col-md-6 form-group">
            <label for="account">Receipt By A/c <span
                    class="text-danger">*</span></label>
            <select name="account" id="account" required class="form-control select" data-placeholder="Select Account">
                <option value="">Select Account</option>
                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($model->id == 1 ? 'selected' : ''); ?> value="<?php echo e($model->id); ?>"><?php echo e($model->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

         
        <div class="col-md-6 form-group">
            <label for="type">Debit/Credit <span
                    class="text-danger">*</span></label>
            <select name="type" id="type" required class="form-control select" data-placeholder="Select Type">
                <option value="">Select Type</option>
                <option  value="Debit">Debit</option>
                <option value="Credit">Credit</option>
            </select>
        </div>

        
        <div class="col-md-6 form-group">
            <label for="amount">Payment Amount <span
                    class="text-danger">*</span></label>
            <input autocomplete="off" type="text" name="amount" required id="amount" class="form-control input_number" placeholder="Enter Payment Amount">
        </div>

        
        <div class="col-md-6 form-group " >
            <label for="operation_date">Operation Date 
            </label>
            <input type="text" name="operation_date" id="operation_date"
                class="form-control take_date" value="<?php echo e(date('Y-m-d')); ?>" placeholder="Enter Operation Date">
        </div>

         
            <div class="col-md-12 form-group">
                <label for="note">Description
                </label>
                    <textarea name="note" class="form-control" id="note" >Opening Balance</textarea>
            </div>

    </div>

    <button type="submit" id="edit_submit" class="btn btn-primary float-right px-5"><i class="fa fa-floppy-o mr-3" aria-hidden="true"></i>Save</button>
    <button type="button" id="edit_submiting" class="btn btn-sm btn-info float-right" id="submiting" style="display: none;">
        <i class="fa fa-spinner fa-spin fa-fw"></i>Loading...</button>

    <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
</form><?php /**PATH E:\Laravel\inventory\resources\views/admin/vaucher/opening-balance.blade.php ENDPATH**/ ?>