<?php $__env->startPush('admin.css'); ?>
<style>
#dashbord_bg{
background-image: url('<?php echo e(asset('images/bg.png')); ?>');
padding: 50px;
background-position: center;
background-repeat: no-repeat;
background-size: cover;
}
.btn-app {
min-width: 100% !important;
height: 106px;
font-size: 27px;
}
.card-1{
background-color: #14c1d7eb;
border: 1px solid #0192a5;
margin-bottom: 20px;
}

.card-2{
background-color: #4caf50;
border: 1px solid #028808;
margin-bottom: 20px;
}

.card-3{
background-color: #f9652c;
border: 1px solid #b93603;
margin-bottom: 20px;
}

.card-4{
background-color: #f9a72c;
border: 1px solid #c07300;
margin-bottom: 20px;
}

i.icon.fa{
float: right;
position: relative;
top: 5px;
left: -10px;
opacity: 0.5;
color: #0000008a;
}
.info h4 {
font-size: 16px;
}
.info p {
font-size: 20px;
margin-top: 10px;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('header'); ?>
<div class="btn-group btn-group-justified ml-3">
    <a href="<?php echo e(route('admin.general.settings')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-cog fa-spin" aria-hidden="true"></i><?php echo app('translator')->get('Setting'); ?></a>
    <a href="<?php echo e(route('today')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-cc-diners-club" aria-hidden="true"></i><?php echo app('translator')->get('Today'); ?></a>
    <a href="https://www.youtube.com/channel/UC02AhNHwgb5C3FGvzo9U0Wg" target="_blank" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-youtube-play" aria-hidden="true"></i><?php echo app('translator')->get('Tutorial'); ?></a>
    <a href="https://sattit.com/" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-question-circle" aria-hidden="true"></i><?php echo app('translator')->get('Help'); ?></a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="dashbord_bg">
    <div class="box bg-white p-3 rounded">
        <div class="row">
            <div class="col-md-6">
                <div class="card-1 pt-2 text-white rounded"><i class="icon fa fa-bar-chart fa-3x"></i>
                    <div class="info p-3">
                        <h4><?php echo app('translator')->get('My Cash'); ?> </h4>
                        <p><b> <?php echo $my_cash; ?></b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card-2 pt-2 text-light rounded"><i class="icon fa fa-bar-chart fa-3x"></i>
                    <div class="info text-white p-3">
                        <h4><?php echo app('translator')->get('My Bank'); ?></h4>
                        <p><b><?php echo $my_bank; ?> </b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card-3 pt-2 text-white rounded"><i class="icon fa fa-bar-chart fa-3x"></i>
                    <div class="info p-3">
                        <h4><?php echo app('translator')->get('Today Recieved'); ?></h4>
                        <p><b><?php echo $receipt_amt; ?></b></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card-4 pt-2 text-white rounded"><i class="icon fa fa-bar-chart fa-3x"></i>
                    <div class="info p-3">
                        <h4><?php echo app('translator')->get('Today Payment'); ?></h4>
                        <p><b> <?php echo $payment_amt; ?> </b></p>
                    </div>
                </div>
            </div>
            

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['title' => 'Today'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/report/today.blade.php ENDPATH**/ ?>