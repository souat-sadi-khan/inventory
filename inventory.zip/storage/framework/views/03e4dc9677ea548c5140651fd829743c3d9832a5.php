<?php $__env->startPush('admin.css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('header'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Loan Register</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-home"
                                aria-hidden="true"></i></a></li>
                    <li class="breadcrumb-item active">Loan Register</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
           <h3>Loan Register Report</h3>
        </div>

        <!-- /.card-header -->
        <div id="print_table" class="card-body">
            <span class="text-center">
                <h3><b class="text-uppercase"><?php echo e(get_option('company_name')); ?></b></h3>
            <h5> <?php echo e(get_option('description')); ?> </h5>
                <h6><?php echo e(get_option('phone')); ?>,<?php echo e(get_option('email')); ?></h6>

            </span>
            <div class="text-center col-md-12">
                <h4 style="margin:0px ; margin-top: 7px; border:solid 1px #000; border-radius:50px; display:inline-block; padding:10px;"
                    class="bg-success text-light">
                    <b>Loan Register Report</b></h4>
            </div>
            <br>
            <div class="table-responsive">
                <table class="table table-sm">
                    <tbody>
                        <tr>
                            <td>

                                <p style="margin:0px ; margin-top: -8px;">

                                    Report Of Date : <span class="ml-1"><?php echo e(formatDate(date('Y-m-d'))); ?></span>

                                </p>

                            </td>
                            <td class="text-center">

                            </td>
                            <td class="text-right">
                                <p style="margin:0px ; margin-top: -8px;">Printing Date :
                                    <span></span> <?php echo e(date('d F, Y')); ?> </span></p>
                                <p style="margin:0px ; margin-top: -4px;">Time :
                                    <span></span><?php echo e(date('h:i:s A')); ?></span></p>
                            </td>
                        </tr>

                    </tbody>
                </table>
            </div>
            <div class="table-responsive">
                <table class="table table-hover table-bordered table-sm">
                    <thead class="table-info">
                        <tr>
                            <th class="text-center">Account</th>
                            <th class="text-right">Debit</th>
                            <th class="text-right">Credit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $t_debit = 0;
                            $t_credit = 0;
                        ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $debit = $ac['debit'] < 0 ? $ac['debit'] *(-1) : $ac['debit'];
                                $credit = $ac['credit'] < 0 ?$ac['credit'] *(-1): $ac['credit'];
                                $t_debit += $debit;
                                $t_credit += $credit ;
                            ?>
                            <tr>

                                <td class="text-center"><a target="_blank" href="<?php echo e(route('admin.report.loan.unique', $ac['id'] .'?sdate='.$sdate.'&edate='.$edate)); ?>"> <?php echo e($ac['account_name']); ?></a></td>
                                <td class="text-right"> <?php echo e(get_option('currency_symbol')); ?> <?php echo e(number_format($debit, 2)); ?></td>
                                <td class="text-right"> <?php echo e(get_option('currency_symbol')); ?> <?php echo e(number_format($credit, 2)); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th class="text-right" colspan="1">Total</th>
                            <th class="text-right"><?php echo e(get_option('currency_symbol')); ?> <?php echo e(number_format($t_debit, 2)); ?></th>
                            <th class="text-right"><?php echo e(get_option('currency_symbol')); ?> <?php echo e(number_format($t_credit, 2)); ?></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <br>
            
            <br><br><br>

            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-4 text-center">
                    <hr class="border-dark">
                    <p> Chief Cashier </p>
                </div>
                <div class="col-md-2"></div>
                <div class="col-md-4 text-center">
                    <hr class="border-dark">
                    <p> Manager </p>
                </div>
                <div class="col-md-1"></div>
            </div>
        </div>
        <div class="text-center mb-3">


            <?php
            $print_table = 'print_table';

            ?>

            <a class="text-light btn-primary btn" onclick="printContent('<?php echo e($print_table); ?>')" name="print"
                id="print_receipt">
                <i class="fa fa-print" aria-hidden="true"></i>
                Print Report

            </a>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin.scripts'); ?>

<script>
    function printContent(el) {
        console.log('print clicked');

        var a = document.body.innerHTML;
        var b = document.getElementById(el).innerHTML;
        document.body.innerHTML = b;
        window.print();
        document.body.innerHTML = a;

        return window.location.reload(true);

    }
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', ['title' => ('Loan Register'), 'modal' => 'xl',], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/report/loan-show.blade.php ENDPATH**/ ?>