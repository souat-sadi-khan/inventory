
<?php $__env->startPush('admin.css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('header'); ?>
<a href="<?php echo e(route('admin.general.settings')); ?>" class="btn btn-light border-right ml-2 py-0"><i
class="fa fa-cog fa-spin" aria-hidden="true"></i><?php echo app('translator')->get('Setting'); ?></a>
<a href="<?php echo e(route('today')); ?>" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-cc-diners-club"
aria-hidden="true"></i><?php echo app('translator')->get('Today'); ?></a>
<a href="https://www.youtube.com/channel/UC02AhNHwgb5C3FGvzo9U0Wg" target="_blank"
    class="btn btn-light border-right ml-2 py-0"><i class="fa fa-youtube-play"
aria-hidden="true"></i><?php echo app('translator')->get('Tutorial'); ?></a>
<a href="https://sattit.com/" class="btn btn-light border-right ml-2 py-0"><i class="fa fa-question-circle"
aria-hidden="true"></i><?php echo app('translator')->get('Help'); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card">
        <div class="card-header">
            <h4>Customer Report</h4>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="card border border-primary">
                <div class="card-body text-center">
                     <div class="row">
                        
                        <div class="col-md-6 form-group mx-auto">
                            <label for="vehicle">Select Customer</label>
                            <select data-url="<?php echo e(route('admin.report.show-customer-due-report')); ?>" name="customer_id" id="customer_id" class="form-control select" data-placeholder="Select Customer">
                                <option value="">Select Customer</option>
                                <option value="all">All Customer</option>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->customer_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="report_data"></div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin.scripts'); ?>
<script>

    $(".select").select2({ width: '100%' });  

    
    $('.select').change(function() {
        var val = $(this).val();
        var url = $(this).data('url');

        $.ajax({
            url: url,
            data: {
                val: val
            },
            type: 'Get',
            dataType: 'html'
        })
        .done(function(data) {
          $('#report_data').html(data);
           toastr.success('Report Genarate');
        })
    });

    $('.select').val('all').trigger('change');  


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', ['title' => ('Customer Report'), 'modal' => 'xl',], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\inventory\resources\views/admin/report/customer-due/index.blade.php ENDPATH**/ ?>