
<div class="col-md-6 mx-auto text-center mb-3 border bg-light border-info">
    <b> Income Account</b>
</div>
<form action="<?php echo e(route('admin.vaucher.income_store')); ?>" method="post" id="modal_form">
    <?php echo csrf_field(); ?>
    <div class="row">
        
        <div class="col-md-4 form-group">
            <label for="income">Income Account A/c <span
                    class="text-danger">*</span></label>
            <select name="income" id="income" data-url="<?php echo e(route('admin.vaucher.balance_check')); ?>" required class="form-control select" data-placeholder="Select Account">
                <option value="">Select Account</option>
                <?php $__currentLoopData = $income; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e($model->id); ?>"><?php echo e($model->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-2 form-group">
            <label for="income_amount">.</label>
            <input type="text" name="income_amount" value="00.00" readonly  id="income_amount" class="form-control" placeholder="Enter Payment Amount">
        </div>


        
        <div class="col-md-4 form-group">
            <label for="bank">Cash/Bank By A/c <span
                    class="text-danger">*</span></label>
            <select name="bank" id="bank" data-url="<?php echo e(route('admin.vaucher.balance_check')); ?>" required class="form-control select" data-placeholder="Select Account">
                <option value="">Select Account</option>
                <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($model->id); ?>"><?php echo e($model->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-2 form-group">
            <label for="bank_amount"> .</label>
            <input type="text" value="00.00" readonly name="bank_amount"  id="bank_amount" class="form-control" placeholder="Enter Payment Amount">
        </div>



        
        <div class="col-md-6 form-group mx-auto" >
            <label for="amount">Payment Amount <span
                    class="text-danger">*</span></label>
            <input type="number" name="amount" required id="amount" class="form-control" placeholder="Enter Receipt Amount">
        </div>


                 
            <div class="col-md-12 form-group">
                <label for="note">Description
                </label>
                    <textarea name="note" class="form-control" id="note" ></textarea>
            </div>



        
        <div class="col-md-6 form-group mx-auto" >
            <label for="operation_date">Operation Date
            </label>
            <input type="text" name="operation_date" id="operation_date"
                class="form-control take_date" value="<?php echo e(date('Y-m-d')); ?>" placeholder="Enter Operation Date">
        </div>



    </div>

    <button type="submit" id="edit_submit" class="btn btn-primary float-right px-5"><i class="fa fa-floppy-o mr-3" aria-hidden="true"></i>Save</button>
    <button type="button" id="edit_submiting" class="btn btn-sm btn-info float-right" id="submiting" style="display: none;">
        <i class="fa fa-spinner fa-spin fa-fw"></i>Loading...</button>

    <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
</form>



<script>

      $(document).on('change', '#bank', function () {
        var value = $(this).val();
        var url = $(this).data('url');

        $.ajax({
            url: url,
            data:{value : value},
            type: 'Get',
            dataType: 'json'
        })
        .done(function(data) {
            console.log(data);

            $('#bank_amount').val(data);

        })
    });



      $(document).on('change', '#income', function () {
        var value = $(this).val();
        var url = $(this).data('url');

        $.ajax({
            url: url,
            data:{value : value},
            type: 'Get',
            dataType: 'json'
        })
        .done(function(data) {
            console.log(data);

            $('#income_amount').val(data);

        })
    });
</script>
<?php /**PATH E:\Laravel\inventory\resources\views/admin/vaucher/income.blade.php ENDPATH**/ ?>